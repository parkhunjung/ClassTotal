           
set serveroutput on;

rollback;

-- ���� ���� ���� ���ν���
create or replace procedure procAddInstruct
(
    pid varchar2,
    ppw varchar2,
    pname varchar2,
    pphone varchar2,
    presult out number
)
is
begin
    insert into tblLogin(id,pw) values(pid,ppw);
    insert into tblInstructor(id,name,tel) values(pid,pname,pphone);
    presult := 1;
commit;
exception
    when others then 
        presult := 0;
            rollback;
    
end;



begin
    procAddInstruct('te','123123','kim','010-6866-9202');
end;

create or replace procedure procAddStudent
(
    pid varchar2,
    ppw varchar2,
    pname varchar2,
    pphone varchar2,
    pmajorCheck varchar2,
    presult out number
)
is
begin
    insert into tblLogin(id,pw) values(pid,ppw);
    insert into tblStudent(id,name,tel,regitDate,majorCheck) 
                        values(pid,pname,pphone,sysdate,pmajorCheck);
    presult := 1;
commit;
exception
    when others then 
        presult := 0;
            rollback;
    
end;

rollback;

select * from tblexecSbject

select * from tblLog;
rollback;
-- ���� ���� ��� ���� ���ν���
create or replace procedure procChangePwInstruct
(
    pid varchar2,
    ppw varchar2
)
is
begin
    update tblLogin set pw = ppw where id = pid;
    
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;


begin
    procChangePwInstruct('instruct01',1111111);
end;


-- ���� ���� �̸� ���� ���ν���
create or replace procedure procChangeNameInstruct
(
    pid varchar2,
    pname varchar2
)
is
begin
    update tblInstructor set name = pname where id = pid;

dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

-- ���� ���� ��ȭ��ȣ ���� ���ν���
create or replace procedure procChangeTelInstruct
(
    pid varchar2,
    ptel varchar2
)
is
begin
    update tblInstructor set tel = ptel where id = pid;
    
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

begin
    procChangeTelInstruct('instruct01','010-6866-9202');
end;


-- ������� ���� ���ν���
create or replace procedure procDelInstruct
(
    pid varchar2,
    presult out number
)
is
begin
    update tblInstructor set name = null, tel = null where id = pid;
    presult := 1;
commit;
exception
    when others then 
        presult := 0;
        rollback;
end;

create or replace procedure procDelStudent
(
    pid varchar2,
    presult out number
)
is
begin
    update tblStudent set name = null, tel = null where id = pid;
    presult := 1;
commit;
exception
    when others then 
        presult := 0;
        rollback;
end;

select * from tblStudentComplete;
alter table tblStudent
modify(name null);


select * from tblStudent;
begin
procDelStudent('test5');
end;

select * from tblCourseBase;
select * from tblCourse;


select * from tblLog2;
SELECT * FROM TBLINSTRUCTOR;


-- �������� �߰� ���ν���
create or replace procedure procAddTextBook
(
    pname varchar2,
    pauthor varchar2,
    ppublisher varchar2
)
is
begin
    insert into tblTextBook values(textbookSeq.nextval,pname,pauthor,ppublisher);

dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;

end;

begin
    procAddTextBook('����� �ڹٴ�','�輮��','�Ѻ����ǻ�');
end;

select * From tblTextBook;


-- �������� �����̸� ���� ���ν���
create or replace procedure procChangeTextBookName
(
    ptextBookNum number,
    ptextBookName varchar2
)
is
begin
    update tblTextBook set textbookname= ptextBookName where textbooknum = ptextBookNum; 
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

begin 
    procChangeTextBookName(30,'�̰��� �ڹٴ�');
end;

-- �������� ���� ���ν���
create or replace procedure procDelTextBook
(
    ptextBookNum number,
    presult out number
)
is
begin
    delete from tbltextbook where textbooknum = ptextBookNum;
    presult := 1;
commit;
exception
    when others then 
            presult := 0;
            rollback;
end;

begin
    procDelTextBook(29); 
end;

rollback;

select * from tbltextbook;

-- ���ǽ� ���� �߰� ���ν���
create or replace procedure procAddLectureRoom
(
    plectureRoomNum number,
    plimitNum number
)
is
begin
    insert into tblLectureRoom values(plectureRoomNum,plimitNum);
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

begin
    procAddLectureRoom(7,30);
end;

-- ���ǽ� ���� ���ǽ� �����ο� ���� ���ν���
create or replace procedure procChangeLimitLectureRoom
(
    plectureRoomNum number,
    plimitNum number
)
is 
begin
    update tblLectureRoom set limitNum = plimitNum 
                            where lectureRoomNum = plectureRoomNum;
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

-- ���ǽ� ���� ���ǽ� ���� ���ν���
create or replace procedure procDelLectureRoom
(
    plectureRoomNum in number
)
is
begin
    update tblCourse set lectureRoomNum = null where lectureRoomNum = plectureRoomNum;
    delete from tblMaterial where lectureRoomNum = plectureRoomNum;
    delete from tblLectureRoom where lectureRoomNum = plectureRoomNum;
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

begin
    procDelLectureRoom(6);
end;



-- �������� �߰� ���ν���
create or replace procedure procAddSubject
(
    pSubjectName varchar2
)
is
begin
    insert into tblSubject values(
        subjectseq.nextval,
        pSubjectName
    );
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
            
end;

select * from tblSubject;

-- �����̸� ���� ���ν���
create or replace procedure procChangeSubjectName
(
    psbjnum number,
    psbjname varchar2
)
is
begin
    update tblSubject set sbjname = psbjname where sbjnum = psbjnum;

dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

-- ���� ���� ���ν���
create or replace procedure procDelSubject
(
psbjNum number
)
is
begin
    update tblInstSbj set sbjNum = null where sbjNum = psbjNum;
    update tblCourseSbject set sbjNum = null where sbjNum = psbjNum;
    delete from tblSubject where sbjnum = psbjNum;
    
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

begin
    procDelSubject(26);
end;


-- ���� ���� �߰� ���ν���
create or replace procedure procAddMaterial
(
    pmaterial varchar2,
    pqty number,
    plectureroomnum number,
    presult out number
)
is
begin
    insert into tblMaterial values(materialSeq.nextval,pmaterial,pqty,plectureroomnum);
    presult := 1;   
commit;
exception
    when others then 
        presult :=0;
            rollback;
end;

begin
    procAddMaterial('�׽�Ʈ',1,2);
end;

-- ���� ���� ������Ʈ ���ν���
create or replace procedure procChangeMaterialQty
(
    pmaterial varchar2,
    plectureroomnum number,
    pqty number,
    presult out number
)
is
begin

    update tblMaterial set qty = pqty  
        where lectureroomnum = plectureroomnum and material = pmaterial;
    presult := 1;   
commit;
exception
    when others then 
            presult := 0;
            rollback;

end;


-- ������ ���� ���ɰ��� �߰� ���ν���
create or replace procedure procAddInstSbj
(
    psbjnum number,
    pid varchar2
)
is
begin
    insert into tblInstSbj values(instsbjseq.nextval,psbjnum,pid);
dbms_output.put_line('�۾��Ϸ�');    
commit;
exception
    when others then 
        dbms_output.put_line('�۾�����');
            rollback;
end;

begin
    procAddInstSbj(6,'instruct10');
end;


-- ����- (�����,�ֹι�ȣ ���ڸ�, ��ȭ��ȣ, ���� ���� ����) view
create view vwAllInstructInfo
as
select tblInstructor.name as "�����", tblLogin.pw as "�ֹι�ȣ ���ڸ�", tblInstructor.tel as "��ȭ��ȣ", tblsubject.sbjname as "���� ���� ����"  
        from tblLogin inner join tblInstructor on tblLogin.id =tblInstructor.id 
    inner join tblInstSbj on tblInstSbj.id =tblInstructor.id  inner join tblSubject on tblSubject.sbjnum =tblInstSbj.sbjnum order by tblInstructor.name;

select * from vwAllInstructInfo;


-- Ư������ (�̸�,�ڽ�,����,��,���ǽǹ�ȣ,����,�ڽ� ����) ���ν���
create or replace procedure procReadInstructCourse
(
    pid in varchar2,
    presult out sys_refcursor
)
is
begin
    
    open presult for
    select name,coursename,startdate,enddate,lectureRoomNum,
            case
                when sysdate between startdate and enddate then '������'
                when sysdate >enddate  then '��������'
                when sysdate<startdate then '���ǿ���'
            end as status   
    
                            from tblInstructor i inner join tblCourse c
                    on i.id = c.id inner join tblCourseBase b 
                        on c.coursenum = b.coursenum 
                                        where i.id = pid;
end;

declare
    vresult sys_refcursor; 
    vname tblInstructor.name%type;
    vcoursename tblCourseBase.coursename%type;
    vstartdate tblCourse.startDate%type;
    venddate tblCourse.endDate%type;
    vlectureroomnum tblCourse.lectureroomnum%type;
    status varchar(12);
begin
    procReadInstructCourse('instruct01',vresult);
    
    loop
        fetch vresult into vname,vcoursename,vstartdate,venddate,vlectureroomnum,status;
        exit when vresult%notfound;
        
        dbms_output.put_line(vname || ' - ' || vcoursename || ' - ' || to_char(vstartdate,'yyyy-mm-dd')|| ' ~ ' 
                ||to_char(venddate,'yyyy-mm-dd')|| ' - ' ||vlectureroomnum||' - ' ||status);
    end loop;     
end;


-- Ư�� ���� (id,name,sbjname,startdate,enddate)�� ���� ���� ������ ���ν���
create or replace procedure procReadInstructExecList
(
     pid in varchar2,
     presult out sys_refcursor   
)
is
begin
    open presult for 
    select i.id,i.name,sbjname,ex.startdate,ex.enddate from tblInstructor i inner join tblCourse c
                    on i.id = c.id inner join tblexecSbject ex
                        on c.coursenum = ex.coursenum inner join tblSubject sbj
                            on ex.sbjnum = sbj.sbjnum
                                where i.id = pid
                                order by i.id,startdate;

end;

set serveroutput on;

declare
    vresult sys_refcursor; 
    vid tblInstructor.id%type;
    vname tblInstructor.name%type;
    vsbjname tblSubject.sbjname%type;
    vstartdate tblexecSbject.startdate%type;
    venddate tblexecSbject.enddate%type;
begin
    procReadInstructExecList('instruct01',vresult);
    
    loop
        fetch vresult into vid,vname,vsbjname,vstartdate,venddate;
        exit when vresult%notfound;
        
        dbms_output.put_line(vid || ' - ' || vname || ' - ' || vsbjname|| ' - ' 
                ||to_char(vstartdate,'yyyy-mm-dd')|| ' ~ ' ||to_char(venddate,'yyyy-mm-dd'));
    end loop;     
end;


-- Ư�� ���������� �����ϸ� �л�����Ʈ �̾Ƴ��� ���ν���
create or replace procedure procReadCourseStudentList
(
    pcourseNum tblcourse.coursenum%type,
    presult out sys_refcursor
)
is
begin
    open presult for 
    select r.id,(select name from tblStudent where id =r.id) as �̸�,attendenceDate,enterTime,exitTime,note 
        from tblCourse c inner join tblRegisterCourse r
            on c.courseNum = r.courseNum inner join tblStuAttendance s
                on r.registerNum = s.registerNum
                    where c.courseNum  = pcourseNum
                        order by id,attendencedate;
end;

declare
    vresult sys_refcursor; 
    vid tblStudent.id%type;
    vname tblStudent.name%type;
    vattendencedate tblStuAttendance.attendenceDate%type;
    ventertime tblStuAttendance.enterTime%type;
    vexittime tblStuAttendance.exitTime%type;
    vnote tblStuAttendance.note%type;
begin
    procReadCourseStudentList(1,vresult);
    
    loop
        fetch vresult into vid,vname,vattendencedate,ventertime,vexittime,vnote;
        exit when vresult%notfound;
        
        dbms_output.put_line(vid || ' - ' || vname || ' - ' || vattendencedate|| ' - ' 
                ||ventertime|| ' - ' ||vexittime|| ' - ' || vnote);
    end loop;     
end;


-----------------------------------------------------
select * from tblLog;
create sequence logSeq;
create table tblLog(
seq number primary key,
code varchar2(30) null,
message varchar2(1000) null,
objectKey varchar2(100) null,
regitDate date default sysdate
)

create or replace trigger trgInstructor
    after
    delete or insert or update
    on tblInstructor
    for each row
declare 
    vcode varchar2(30);
    vmessage varchar2(1000);
    vobjectKey varchar2(100);
begin
    if inserting then
        vcode := 'tblInstructor_Inserting';
        vmessage := 'tblInstructor ���̺��� ���ο� ���ڵ尡 �߰��Ǿ����ϴ�.';
    elsif updating then
        vcode := 'tblInstructor_Updating';
        vmessage := 'tblInstructor ���̺��� ���ڵ尡 �����Ǿ����ϴ�.';
    elsif deleting then
        vcode := 'tblInstructor_Deleting';
        vmessage := 'tblInstructor ���̺��� ���ڵ尡 �����Ǿ����ϴ�.';
    end if;
        vobjectKey := :new.id;
    insert into tblLog(seq,code,message,objectKey,regitdate) values ( logSeq.nextval,vcode,vmessage,to_char(vobjectKey),default);
    
end;

select * from tblInstructor;

select * from tblLog;

create or replace trigger trgCourse
    after
    delete or insert or update
    on tblCourse
    for each row
declare 
    vcode varchar2(30);
    vmessage varchar2(1000);
    vobjectKey varchar2(100);
begin
    if inserting then
        vcode := 'tblCourse_Inserting';
        vmessage := 'tblCourse ���̺��� ���ο� ���ڵ尡 �߰��Ǿ����ϴ�.';
    elsif updating then
        vcode := 'tblCourse_Updating';
        vmessage := 'tblCourse ���̺��� ���ڵ尡 �����Ǿ����ϴ�.';
    elsif deleting then
        vcode := 'tblCourse_Deleting';
        vmessage := 'tblCourse ���̺��� ���ڵ尡 �����Ǿ����ϴ�.';
    end if;
    vobjectKey := :new.courseNum;
    insert into tblLog(seq,code,message,objectKey,regitdate) values ( logSeq.nextval,vcode,to_char(vobjectKey),vmessage,default);
    
end;






desc tblLog;


-- ������ ���� ���� 
create or replace function fnpartRatio
(
    ppartperson number,
    pallperson number
) return number
is
begin
    return round((ppartperson/pallperson)*100,1);
end;


create or replace procedure procGenderRatio
(
    pcourseNum in number,
    pManCount out number,
    pWomanCount out number
)
is
begin
    
        select count(*) into pManCount from tblLogin 
        where id in (select id from tblRegisterCourse where courseNum = pcourseNum)
             and pw like '1%';
       
    
   
        select count(*) into pWomanCount from tblLogin 
        where id in (select id from tblRegisterCourse where courseNum = pcourseNum)
             and pw like '2%';
        
end;

create or replace procedure procCourseGenderRatio
(
    pcourseNum number
)
is
    vManCount number(3);
    vWomanCount number(3);
begin
    procGenderRatio(pcourseNum,vManCount,vWomanCount);
    
    dbms_output.put_line('���� ����:'||fnpartRatio(vManCount,(vManCount+vWomanCount))||'%');
    dbms_output.put_line('���� ����:'||fnpartRatio(vWoManCount,(vManCount+vWomanCount))||'%');
end;

begin
procCourseGenderRatio(3);
end;


create or replace procedure procLectureRoomStudent
(
    plectureRoomNum number,
    presult out sys_refcursor
)
is
begin
open presult for
select id,name,tel,majorCheck from tblStudent
where id in
(select id from tblRegisterCourse 
where courseNum = 
(select courseNum from tblCourse 
where lectureRoomNum = plectureRoomNum and sysdate between startDate and endDate));
end;


-- 1�� �ڽ��� 8�� �⼮��
select round((select count(*) from tblStuAttendance 
where to_char(attendencedate,'mm')=8 and registerNum in(select registerNum from tblRegisterCourse where courseNum = 1) and note ='����')/(select count(*) from tblStuAttendance where substr(attendencedate,7,1)=8 and registerNum in(select registerNum from tblRegisterCourse where courseNum = 1)),3)*100 as attenPer from dual;

select to_char(attendencedate,'mm') from tblStuAttendance;

select * from tblStuAttendance;

-- 1�� �ڽ��� 8�� �Ἦ Ƚ��
select count(*) as cnt from tblStuAttendance where substr(attendencedate,7,1)=8 and note ='����' and registerNum in (select registerNum from tblRegisterCourse where courseNum =1);

-- student001 �� 8�� �⼮��
select round((select count(*) from tblStuAttendance where note ='����' and to_char(attendencedate,'mm')=8 and registernum= (select registernum from tblRegisterCourse where id = 'student001'))/(select count(*) from tblStuAttendance where to_char(attendencedate,'mm')=8 and registernum= (select registernum from tblRegisterCourse where id = 'student001')),3)*100 as per from dual;

--student001 �� 8�� ���Ƚ��
select count(*) from tblStuAttendance where note ='����' and to_char(attendencedate,'mm')=8 and registernum= (select registernum from tblRegisterCourse where id = 'student001');

-- student001 �� 8�� ����,���� Ƚ��
select count(*) from tblStuAttendance where note ='����' and to_char(attendencedate,'mm')=8 and registernum= (select registernum from tblRegisterCourse where id = 'student001');
select * from tblExam;
select * from tblScore;

select * from vwScore;

select * from 
(select (select id from tblRegisterCourse where registerNum = s.registerNum) as id,
(select name from tblStudent 
where id=(select id from tblRegisterCourse where registerNum = s.registerNum)) as name,s.*,(select coursename from tblCourseBase where coursenum=(select coursenum from tblRegisterCourse where registerNum = s.registerNum)) as coursename from tblScore s) where id =?;


select * from tblLogin;

delete from tblInstructor where name is null;

select * from tblInstructor;
commit;

select * from tblMaterial;
select * from tblInstructor;
select * from tblStudent;

select * from tblStudentComplete;

select * from tblLogin;

select * from tblAppraisal;

delete from tblAppraisal where apprajsal = 'test';
commit;
insert into tblAppraisal values(1,'�ڡڡڡڡ� �׻� ģ���� �˷��ֽð� ���� �����߽��ϴ�.',sysdate,1);
commit;
delete from tblAppraisal where registernum =1;
commit;

select * from tblexecSbject;
commit;
delete from tblexecSbject where execsbjNum = 29;
select courseName from tblCourseBase where courseNum =(select courseNum from tblCourse where sysdate between startDate and endDate and id = 'instruct01');

select name from tblInstructor where id = (select id from tblCourse where courseNum = (select courseNum from tblRegisterCourse where id = 'student001'));

select * from tblStuAttendance;

select attendenceDate from tblStuAttendance where to_char(attendencedate,'mm')=8 and registerNum =(select registerNum from tblRegisterCourse where id = 'student001') and note='����';

