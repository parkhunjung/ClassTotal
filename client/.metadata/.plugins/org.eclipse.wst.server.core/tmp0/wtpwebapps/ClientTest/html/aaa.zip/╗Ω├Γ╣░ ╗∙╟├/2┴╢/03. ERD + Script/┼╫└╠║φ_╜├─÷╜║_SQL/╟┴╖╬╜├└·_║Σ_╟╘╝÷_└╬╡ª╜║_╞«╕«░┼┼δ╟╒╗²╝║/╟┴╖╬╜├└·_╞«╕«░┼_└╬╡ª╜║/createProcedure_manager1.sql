-- createProcedure.sql

set serveroutput on;

-- procMaSelStudentStatus ����
create or replace procedure procMaSelStudentStatus
(
    pname varchar2,
    presult out sys_refcursor -- ��ȯ�����θ� ����ϴ� cursor �ڷ���
    
)
is
begin
    
    open presult for
    select s.student_seq as"student_seq", stu.student as "student" ,s.finish_status as "finish_status" from tblmanager e
        inner join tblclassroom c
            on c.manager_seq = e.manager_seq    
                inner join tblenrollstudent s
                    on s.classroom_seq = c.classroom_seq
                        inner join tblstudent stu
                            on s.student_seq = stu.student_seq
                                where stu.student = pname;
    commit;

exception
    when others then
    rollback;
        
   

end;

-- procMaSelStudentStatus Ȯ��
declare
    vresult sys_refcursor;
    vstudent_seq tblenrollstudent.student_seq%type;
    vstudent tblstudent.student%type;
    vfinish_status tblenrollstudent.finish_status%type;
begin
    procMaSelStudentStatus('�輼��',vresult);
    
    loop
        fetch vresult into vstudent_seq, vstudent, vfinish_status;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent_seq||'-'|| vstudent||'-'|| vfinish_status);
    
    
    end loop;
    
end;

-------------------------------------------------------------------------------------------

--procMaUpdStudentStatus ����
create or replace procedure procMaUpdStudentStatus_part1
(
    pstatus varchar2,
    pmonth varchar2,
    presult out sys_refcursor
)
is

begin

    open presult for
    select
        es.student_seq,
        count(es.student_seq)
        from tblenrollstudent es
            inner join tblattendance a
                on es.student_seq = a.student_seq
                    where a.attendance_status = pstatus
                    and to_char(a.attdate,'mm') = pmonth
                        group by es.student_seq;
    
exception
    when others then
        rollback;
    
end;

create or replace procedure procMaUpdStudentStatus_part2
(
    pseq number,
    pcount number

)
is
begin
    
    if pcount >= 5 then
        update tblenrollstudent set 
            finish_status = '�ߵ�Ż��' 
                where student_seq = pseq;
            
        update tblenrollstudent set 
            p_np_date = sysdate 
                where student_seq = pseq;        
            
    end if;

    
exception
    when others then
        rollback;
    
end;





-- procMaUpdStudentStatus Ȯ��
declare
    vresult sys_refcursor;
    vstudent_seq tblenrollstudent.student_seq%type;
    vmonth tblattendance.attdate%type;
    vcount number;

    
begin
    procMaUpdStudentStatus_part1('�Ἦ','08',vresult);
    
    loop
        fetch vresult into vstudent_seq, vcount;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent_seq || ' - ' || vcount);
        
        procMaUpdStudentStatus_part2(vstudent_seq, vcount);
    
    end loop;
    
    dbms_output.put_line('����Ϸ�');
    
end;

rollback;

commit;

-------------------------------------------------------------------------------------------

-- procMaDelStudent ����
create or replace procedure procMaDelStudent
(
    pname varchar2,
    presult out number
)
is
    vseq number;
begin
    
    select student_seq into vseq from tblstudent where student = pname;
    
    if vseq is not null then
        presult := 1;
    else
        presult := 0;
    end if;

    delete from tblattendance where student_seq=vseq; --���
    delete from tblpay where student_seq=vseq; --����������
    delete from tblgrade where student_seq=vseq;--����
    delete from tblteacherscore where student_seq=vseq;--������
    delete from tblsugang where student_seq=vseq;--������û&����
    delete from tblenrollstudent where student_seq=vseq;--����л�����
    delete from tblstudent where student_seq=vseq; --�⺻�л����� ����
    
    
    
exception
    when others then
        presult := 0;
        rollback;
end;


-- procMaDelStudent Ȯ��
declare
    vseq number;
begin
    procMaDelStudent(1);
end;



rollback;

-------------------------------------------------------------------------------------------

-- procMaUpdStudent ����
create or replace procedure procMaUpdStudent
(
    pname varchar2,
    ptel varchar2,
    pcategory varchar2
    
)
is
begin

update tblstudent 
set 
tel = ptel, 
category_seq = (select category_seq from tblcategory where category = pcategory)
where student = pname;
    
    

exception
    when others then
        rollback;
end;


-- procMaUpdStudent Ȯ��
begin
   procMaUpdStudent(2,'������','1555551','010-9999-9999',1); 
   dbms_output.put_line('����Ϸ�');
end;

rollback;

-------------------------------------------------------------------------------------------


select * from tblStudent;

set SERVEROUTPUT ON;


-- procMaSelStudentCategory ����
create or replace procedure procMaSelStudentCategory
(
    pname varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select 
    s.student_seq as "student_seq",
    s.student as "student",
    s.ssn as "ssn",
    s.tel as "tel",
    s.enrolldate as "enrolldate",
    c.category as "category",
    (select count(*) from tblenrollstudent where student_seq= s.student_seq) as "sugang_count"
    from tblstudent s
        inner join tblenrollStudent es
            on s.student_seq =es.student_seq
                inner join tblcategory c
                    on c.category_seq = s.category_seq
                        where s.student = pname;


exception
    when others then
        rollback;
end;

-- procMaSelStudentCategory Ȯ��
declare
    vresult sys_refcursor;
    vstudent_seq tblstudent.student_seq%type;
    vstudent tblstudent.student%type;
    vssn tblstudent.ssn%type;
    vtel tblstudent.tel%type;
    venrolldate tblstudent.enrolldate%type;
    vcategory tblCategory.category%type;
    vcnt number;
begin

    procMaSelStudentCategory('������',vresult);
    
    loop
        fetch vresult into 
            vstudent_seq,
            vstudent,
            vssn,
            vtel,
            venrolldate,
            vcategory,
            vcnt;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent_seq||'-'|| vstudent||'-'|| vssn ||'-'|| vtel ||'-'|| venrolldate ||'-'|| vcategory || '-' || vcnt);
    
    
    end loop;
    
end;

-------------------------------------------------------------------------------------------

-- procMaInsStudent ����
create or replace procedure procMaInsStudent
(
    pname varchar2,
    pssn varchar2,
    ptel varchar2,
    pcateseq number
)
is
begin

    insert into tblstudent (student_seq,student,ssn,tel,enrolldate,category_seq)
        values (student_seq.nextval,pname,pssn,ptel,sysdate,pcateseq);


exception
    when others then
        rollback;
end;


-- procMaInsStudent Ȯ��
begin
    procMaInsStudent('�ֵ���', '1505001', '010-2685-6838', 2);
end;
rollback;


-------------------------------------------------------------------------------------------

-- procMaSelStudentOcOsTs ����
create or replace procedure procMaSelStudentOcOsTs
(
    pname varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select 
        distinct 
        st.student as "st.student",
        st.ssn as "ssn",
        st.tel as "tel",
        st.enrolldate as "enrolldate",
        c.curriculum as "curriculum", 
        s.subject as "subject",
        t.teacher as "teacher",
                case
                    when ts.point is not null then '�� �Ϸ�'
                    when ts.point is null then '�� �̿Ϸ�'
                end as "point"
        from tblEnrollStudent e
            left outer join tblTeacherScore ts
                on e.student_seq=ts.student_seq
                    left outer join tblOpenCurriculum oc
                        on oc.classroom_seq=e.classroom_seq
                            left outer join tblCurriculum c
                                on c.curriculum_seq=oc.curriculum_seq
                                    left outer join tblOpenSubject os
                                        on os.openclass_seq=oc.openclass_seq
                                            left outer join tblSubject s
                                                on s.subject_seq=os.subject_seq
                                                    left outer join tblTeacher t
                                                        on t.teacher_seq=os.teacher_seq
                                                            left outer join tblStudent st
                                                                on e.student_seq=st.student_seq
                                                                    where st.student = pname;


exception
    when others then
        rollback;
end;


-- procMaSelStudentOcOsTs  Ȯ��
declare
    vresult sys_refcursor;
    vstudent tblStudent.student%type;
    vssn tblStudent.ssn%type;
    vtel tblStudent.tel%type;
    venrolldate tblStudent.enrolldate%type;
    vcurriculum tblCurriculum.curriculum%type;
    vsubject tblsubject.subject%type;
    vteacher tblteacher.teacher%type;
    vpoint varchar2(100);
begin

    procMaSelStudentOcOsTs('�Ѽ���',vresult);
    

    loop
        fetch vresult into 
            vstudent,
            vssn,
            vtel,
            venrolldate,
            vcurriculum,
            vsubject,
            vteacher,
            vpoint;
                
        if vstudent is null then
            dbms_output.put_line('���� ������ ��ϵ� �л��� �ƴմϴ�!');
        else
            dbms_output.put_line(vstudent||'-'|| vssn ||'-'|| vtel ||'-'|| venrolldate ||'-'|| vcurriculum || '-' || vsubject || '-' || vteacher || '-' || vpoint);    
        end if;
                
        exit when vresult%notfound;
            
        
    end loop;
      

end;



-------------------------------------------------------------------------------------------

-- procMaSelEsGrade ����
create or replace procedure procMaSelEsGrade
(
    pstudentName varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select 
    s.student as "student" ,--������
    s.ssn as "ssn" ,--�ֹι�ȣ
    cu.curriculum as "curriculum", --����
    openc.curriculum_start as "curriculum_start", --���� ����
    openc.curriculum_end as "curriculum_end" , --���� ��
    c.classroom as "classroom", --���ǽ�
    sub.subject as "subject", --����
    opens.subject_start as "subject_start", --���� ����
    opens.subject_end as "subject_end", --���� ��
    tea.teacher as "teacher", --����
    g.attendance as "attendance" , --���
    g.written_exam as "written_exam", --�ʱ�
    g.skill_test as "skill_test" --�Ǳ�


    from tblenrollstudent e --��� ������
        inner join tblstudent s  --������ ����
            on e.student_seq = s.student_seq
                inner join tblopencurriculum openc --���� ����
                    on e.openclass_seq = openc.classroom_seq
                        inner join tblclassroom c --���ǽ� ����
                            on openc.classroom_seq = c.classroom_seq
                                inner join tblcurriculum cu --���� ����
                                    on openc.curriculum_seq = cu.curriculum_seq
                                        inner join tblopensubject opens -- ���� ����
                                            on opens.openclass_seq = openc.openclass_seq
                                                inner join tblsubject sub --���� ����
                                                    on opens.subject_seq = sub.subject_seq
                                                        inner join tbltest t --����
                                                            on opens.openclass_seq = t.openclass_seq 
                                                                and opens.subject_seq = t.subject_seq
                                                                    left outer join tblgrade g --����
                                                                        on e.student_seq = g.student_seq
                                                                            left outer join tblstudent s --������ ����
                                                                                on e.student_seq = s.student_seq
                                                                                    left outer join tblteacher tea --���� ����
                                                                                        on opens.teacher_seq = tea.teacher_seq
                                                                                            where s.student = pstudentName;

exception
    when others then
        rollback;
end;



-- procMaSelEsGrade Ȯ��
declare
    vresult sys_refcursor;
    vstudent tblStudent.student%type;--������ �̸�
    vssn tblStudent.ssn%type;--�ֹι�ȣ
    vcurriculum tblCurriculum.curriculum%type;--����
    vcurriculum_start tblOpenCurriculum.curriculum_start%type;--���� ����
    vcurriculum_end tblOpenCurriculum.curriculum_end%type;--���� ��
    vclassroom tblClassroom.classroom%type;--���ǽ�
    vsubject tblSubject.subject%type;--����
    vsubject_start tblOpenSubject.subject_start%type;--���� ����
    vsubject_end tblOpenSubject.subject_end%type;--���� ��
    vteacher tblTeacher.teacher%type;--����
    vattendance tblGrade.attendance%type; --���
    vwritten_exam tblGrade.written_exam%type;--�ʱ�
    vskill_test tblGrade.skill_test%type; --�Ǳ�
begin

    procMaSelEsGrade('������',vresult);   

    loop
        fetch vresult into 
            vstudent,
            vssn,
            vcurriculum,
            vcurriculum_start,
            vcurriculum_end,
            vclassroom,
            vsubject,
            vsubject_start,
            vsubject_end,
            vteacher,
            vattendance,
            vwritten_exam,
            vskill_test;
                
        if vstudent is null then
            dbms_output.put_line('�˻��Ͻ� �л��� ���� ������ ��ϵ� �л��� �ƴմϴ�!');
            exit when vresult%notfound; 
        else
            exit when vresult%notfound; 
            dbms_output.put_line(vstudent||'-'|| vssn ||'-'|| vcurriculum ||'-'|| vcurriculum_start || '-' || vcurriculum_end 
                                || '-' || vclassroom || '-' || vsubject || '-' || vsubject_start || '-' || vsubject_end || '-' || vteacher
                                || '-' || vattendance || '-' || vwritten_exam || '-' || vskill_test);    
        end if;
                       
        
    end loop;

end;

-------------------------------------------------------------------------------------------

-- procMaSelOsGrade ����
create or replace procedure procMaSelOsGrade
(
    psubject varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select 
    stu.student_seq as "student_seq",
    stu.student as "student",
    c.curriculum as "curriculum",
    s.subject as "subject",
    g.attendance as "attendance",
    g.skill_test as "skill_test",
    g.written_exam as "written_exam"

    from tblopencurriculum openc
        inner join tblcurriculum c
            on openc.curriculum_seq = c.curriculum_seq
                inner join tblopensubject opens
                    on opens.openclass_seq = openc.openclass_seq
                        inner join tblsubject s
                            on s.subject_seq = opens.subject_seq
                                inner join tblenrollstudent ens
                                    on opens.openclass_seq = ens.openclass_seq
                                        inner join tblstudent stu
                                            on stu.student_seq = ens.student_seq
                                                inner join tblgrade g
                                                    on g.student_seq = ens.student_seq
                                                        where s.subject = psubject;
exception
    when others then
        rollback;
end;

-- procMaSelOsGrade Ȯ��

declare
    vresult sys_refcursor;
    vstudent_seq tblStudent.student_seq%type;
    vstudent tblStudent.student%type;
    vcurriculum tblcurriculum.curriculum%type;
    vsubject tblsubject.subject%type;
    vattendance tblgrade.attendance%type;
    vskill_test tblgrade.skill_test%type;
    vwritten_exam tblgrade.written_exam%type;
    
begin

    procMaSelOsGrade('���α׷��� ���� ����',vresult);   

    loop
        fetch vresult into
            vstudent_seq,
            vstudent,
            vcurriculum,
            vsubject,
            vattendance,
            vskill_test,
            vwritten_exam;
            
                
        if vstudent is null then
            dbms_output.put_line('�˻��Ͻ� ������ �������� �ʾҽ��ϴ�!');
            exit when vresult%notfound; 
        else
            exit when vresult%notfound; 
            dbms_output.put_line(vstudent_seq||'-'||vstudent||'-'|| vcurriculum ||'-'|| vsubject || '-' || vattendance || '-' || vskill_test || '-' ||  vwritten_exam);    
        end if;
                       
        
    end loop;

    

end;


-------------------------------------------------------------------------------------------
-- procMaSelOsOcSgs ����
create or replace procedure procMaSelOsOcSgs
(
    pcurrname varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select 
    sub.subject as "subject", --���� ������ �ش�� ���� ��
    t.teacher as "teacher", --���� ���� ��� ���� ��
    b.book as "book", --���� �ش� �� ���� ��
    opens.subject_start as "subject_start",--���� ���� �Ⱓ
    opens.subject_end as "subject_end", --���� �� �Ⱓ
    opens.class_status as "class_status", --���� ���� ����
    ts.test_status as "test_status",-- ���� ��� ����
    gt.grade_status as "grade_status" --���� ��� ����
    
    from tblopencurriculum openc
        right outer join tblopensubject opens --���� ���� 
            on openc.openclass_seq = opens.openclass_seq
                inner join tblsubject sub --���� ���� ����
                    on opens.subject_seq = sub.subject_seq
                        inner join tblteacher t --���� ���� ����
                            on opens.teacher_seq = t.teacher_seq
                                inner join tblbook b --���� ���� ����
                                    on opens.book_seq = b.book_seq
                                        inner join tblsubjectteststatus ts
                                                on ts.openclass_seq = opens.openclass_seq
                                                    and ts.subject_seq = opens.subject_seq
                                                        inner join tblsubjectgradestatus gt
                                                            on gt.openclass_seq = opens.openclass_seq
                                                                and gt.subject_seq = opens.subject_seq
                                                                    inner join tblCurriculum c
                                                                        on c.curriculum_seq = openc.curriculum_seq
                                                                            where c.curriculum = pcurrname;

end;


-- procMaSelOsOcSgs Ȯ��

declare
    vresult sys_refcursor;
    vsubject tblsubject.subject%type; --���� ������ �ش�� ���� ��
    vteacher tblteacher.teacher%type; --���� ���� ��� ���� ��
    vbook tblbook.book%type; --���� �ش� �� ���� ��
    vsubject_start tblopensubject.subject_start%type; --���� ���� �Ⱓ
    vsubject_end tblopensubject.subject_end%type; --���� �� �Ⱓ
    vclass_status tblopensubject.class_status%type; --���� ���� ����
    vtest_status tblsubjectteststatus.test_status%type; -- ���� ��� ����
    vgrade_status tblsubjectgradestatus.grade_status%type; --���� ��� ����

begin

    procMaSelOsOcSgs('�� ���ø����̼� ���� SW �ǹ� ������ �缺 ����',vresult);   

    loop
        fetch vresult into
            vsubject,
            vteacher,
            vbook,
            vsubject_start,
            vsubject_end,
            vclass_status,
            vtest_status,
            vgrade_status;
            
                
        if vsubject is null then
            dbms_output.put_line('�˻��Ͻ� ������ �������� �ʾҽ��ϴ�!');
            exit when vresult%notfound; 
        else
            exit when vresult%notfound; 
            dbms_output.put_line(vsubject||'-'||vteacher||'-'|| vbook ||'-'|| vsubject_start || '-' || vsubject_end || '-' || vclass_status || '-' ||  vtest_status || '-' ||  vgrade_status);    
        end if;
                       
        
    end loop;

end;

-------------------------------------------------------------------------------------------
-- procMaUpdOs ����
create or replace procedure procMaUpdOs
(
    psub_seq number,
    popen_seq number,
    pbook_seq number,
    pteacher_seq number,
    psubject_start date,
    psubject_end date
)
is
begin 

    update tblOpenSubject set 
        book_seq = pbook_seq,
        teacher_seq = pteacher_seq,
        subject_start = psubject_start,
        subject_end = psubject_end
    where subject_seq = psub_Seq and openclass_seq = popen_seq;
    
    if psubject_start > sysdate and psubject_end > sysdate then
        update tblopensubject set class_status = '���ǿ���' where subject_seq = psub_Seq and openclass_seq = popen_seq;
    elsif psubject_start <= sysdate and psubject_end >= sysdate then
        update tblopensubject set class_status = '������' where subject_seq = psub_Seq and openclass_seq = popen_seq;
    elsif psubject_start < sysdate and psubject_end < sysdate then
        update tblopensubject set class_status = '��������' where subject_seq = psub_Seq and openclass_seq = popen_seq;
    end if;
    
    dbms_output.put_line('������Ʈ�� �Ϸ� �Ǿ����ϴ�.');

exception
    when others then
        rollback;

    
    
end;

set serveroutput on;

-- procMaUpdOs Ȯ��

begin
    
    procMaUpdOs(2,1,2,10,'2018-08-21','2018-10-02');
    

end;

-------------------------------------------------------------------------------------------
-- procMaDelOs ����(��������, ��������)
create or replace procedure procMaDelOs(

    popen_seq number,
    psub_seq number

)
is
begin

    dbms_output.put_line('1.1 ���� ���� �����ϱ�');
    
    delete from tbltestdate 
        where test_seq in(select test_seq from tbltest where openclass_seq = popen_seq and subject_seq = psub_seq);
    dbms_output.put_line('���� ��¥ ����');
    
    delete from tbltestquestion
        where test_seq in(select test_seq from tbltest where openclass_seq = popen_seq and subject_seq = psub_seq);
    dbms_output.put_line('���� ���� ����');
    
    delete from tblpoint 
        where test_seq in(select test_seq from tbltest where openclass_seq = popen_seq and subject_seq = psub_seq);
    dbms_output.put_line('���� ���� ����');
    
    delete from tblgrade 
        where test_seq in(select test_seq from tbltest where openclass_seq = popen_seq and subject_seq = psub_seq);
    dbms_output.put_line('���� ����');
    
    delete from tbltest 
        where openclass_seq = popen_seq and subject_seq = psub_seq;
    dbms_output.put_line('���� ����');
        
    dbms_output.put_line('1.2 ���� ���蹮��, ���� ��Ͽ��� ����');
    
    delete from tblsubjectteststatus 
        where openclass_seq = popen_seq and subject_seq = psub_seq;
    dbms_output.put_line('���蹮�� ���� ��Ͽ��� ����');
        
    delete from tblsubjectgradestatus 
        where openclass_seq = popen_seq and subject_seq = psub_seq;
    dbms_output.put_line('���� ��� ���� ����');
        
    delete from tblteacherscore
        where openclass_seq = popen_seq and subject_seq = psub_seq;
    dbms_output.put_line('���� �� ����');
    
    delete from tblteacherbonus
        where openclass_seq = popen_seq and subject_seq = psub_seq;
    dbms_output.put_line('���� �μ�Ƽ�� ����');    
    
    delete from tblopensubject
        where openclass_seq = popen_seq and subject_seq = psub_seq;
    dbms_output.put_line('���� ���� ���� ����');

exception
    when others then
        rollback;
end;



-- procMaDelOs Ȯ��(��������, ��������)
begin
    procMaDelOs(2,1);
end;

commit;
rollback;

-------------------------------------------------------------------------------------------
-- procMaSelOcOs(������, Ŀ��) > �ش� ������ ���� ��� ����
create or replace procedure procMaSelOcOs(
    pcurriculum in varchar2,
    presult out sys_refcursor
)
is
begin
    
    open presult for
    select 
        sub.subject as "subject", --���� ������ �ش�� ���� ��
        t.teacher as "teacher", --���� ���� ��� ���� ��
        b.book as "book", --���� �ش� �� ���� ��
        opens.subject_start as "subject_start",--���� ���� �Ⱓ
        opens.subject_end as "subject_end", --���� �� �Ⱓ
        opens.class_status as "class_status" --���� ���� ����
        
        from tblopencurriculum openc
            right outer join tblopensubject opens --���� ���� 
                on openc.openclass_seq = opens.openclass_seq
                    inner join tblsubject sub --���� ���� ����
                        on opens.subject_seq = sub.subject_seq
                            inner join tblteacher t --���� ���� ����
                                on opens.teacher_seq = t.teacher_seq
                                    inner join tblbook b --���� ���� ����
                                        on opens.book_seq = b.book_seq
                                            inner join tblcurriculum c
                                                on openc.curriculum_seq = c.curriculum_seq
                                                where c.curriculum = pcurriculum;


exception
    when others then
        rollback;


end;

-- procMaSelOcOs(������, Ŀ��) > �ش� ������ ���� ��� Ȯ��

declare
    vresult sys_refcursor;
    vsubject tblsubject.subject%type; --���� ������ �ش�� ���� ��
    vteacher tblteacher.teacher%type; --���� ���� ��� ���� ��
    vbook tblbook.book%type; --���� �ش� �� ���� ��
    vsubject_start tblopensubject.subject_start%type; --���� ���� �Ⱓ
    vsubject_end tblopensubject.subject_end%type; --���� �� �Ⱓ
    vclass_status tblopensubject.class_status%type; --���� ���� ����
    
begin
    procMaSelOcOs('�� ���ø����̼� ���� SW �ǹ� ������ �缺 ����',vresult);
    
    loop
        fetch vresult into vsubject, vteacher, vbook, vsubject_start, vsubject_end, vclass_status;
        exit when vresult%notfound;
        
        dbms_output.put_line(vsubject||'-'|| vteacher ||'-'|| vbook  ||'-'|| vsubject_start  ||'-'|| vsubject_end  ||'-'|| vclass_status);
    
    
    end loop;

end;


-------------------------------------------------------------------------------------------

-- procMaUpdOsTeacher() ����

-------------------------------------------------------------------------------------------

-- procMaUpdOsBook() ����
create or replace procedure procMaUpdOsBook(
    pbook varchar2
)
is
begin
    
    update tblopensubject set teacher_seq = '�ٲ� ���� seq'
        where openclass_seq = '���� ���� seq' and subject_seq = '���� ���� seq';


end;

-------------------------------------------------------------------------------------------

create or replace procedure procMaInsOs(

    psubject_seq number,
    popenclass_seq number,
    pbook_seq number,
    pteacher_seq number
    
)
is
    
begin
    
    insert into tblopensubject
        (subject_seq,openclass_seq,book_seq,teacher_seq, subject_start, subject_end, class_status)
            values (psubject_seq,popenclass_seq,pbook_seq,pteacher_seq,null,null,null);

exception
    when others then
        dbms_output.put_line('���簡 ������ �� ���� �����Դϴ�!');
        rollback;


end;




-------------------------------------------------------------------------------------------

-- procMaSelOcOsEs ����
create or replace procedure procMaSelOcOsEs
(
    popenclass_seq in tblOpenCurriculum.openclass_seq%type,
    pcursor out sys_refcursor 
)
is
begin
    open pcursor for
    select 
    oc.openclass_seq as openclass_seq,
    c.classroom as classroom,
    to_char(oc.curriculum_start,'yyyy-mm-dd')||'~'||to_char(oc.curriculum_end,'yyyy-mm-dd') as curriculum_term,
    case 
        when oc.subject_status = 'Y' then '���'
        when oc.subject_status = 'N' then '�̵��'
    end as subject_status, --��������
    sub.subject as subject,
    to_char(os.subject_start,'yyyy-mm-dd')||'~'||to_char(os.subject_end,'yyyy-mm-dd') as "subject_term",
    t.teacher as teacher,
    b.book as book,--��������
    s.student as student,
    s.tel as tel,
    s.enrolldate as enrolldate,
    case
        when s.category_seq = '1' then '�Ϲ�'
        when s.category_seq = '2' then  '���������Ű��'
    end as category
from tblopencurriculum oc
    inner join tblenrollStudent es
        on oc.openclass_seq = es.openclass_seq
            inner join tblstudent s
                on s.student_seq = es.student_seq
                    inner join tblopensubject os
                        on oc.openclass_seq = os.openclass_seq
                            inner join tblClassRoom c
                                on oc.classroom_seq = c.classroom_seq
                                    inner join tblsubject sub
                                        on sub.subject_seq = os.subject_seq
                                            inner join tblteacher t
                                                on os.teacher_seq = t.teacher_seq
                                                    inner join tblBook b
                                                        on os.book_seq = b.book_seq
                                                            where oc.openclass_seq=popenclass_seq;

exception
    when others then
        rollback;  
end;


--ȣ�� 
set serveroutput on;

declare
    vresult sys_refcursor;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vclassroom tblclassroom.classroom%type;
    vcurriculum_term varchar2(60);
    vsubject_status varchar2(30); --��������
    
    vsubject tblsubject.subject%type;
    vsubject_term varchar2(60);
    vteacher tblteacher.teacher%type;
    vbook tblbook.book%type; --��������
    
    vstudent tblstudent.student%type;
    vtel tblstudent.tel%type;
    venrolldate tblstudent.enrolldate%type;
    vcategory varchar2(50); --�л�����
    
begin
    procMaSelOcOsEs(2,vresult);
    
    loop
        fetch vresult into vopenclass_seq
                          ,vclassroom
                          ,vcurriculum_term
                          ,vsubject_status 
                          
                          ,vsubject
                          ,vsubject_term
                          ,vteacher
                          ,vbook 
                          
                          ,vstudent
                          ,vtel
                          ,venrolldate
                          ,vcategory ;
                          
        exit when vresult%notfound;
        
        dbms_output.put_line(vopenclass_seq||','||
                             vclassroom||','||
                             vcurriculum_term||','||
                             vsubject_status||','||
                            
                             vsubject||','||
                             vsubject_term||','||
                             vteacher||','||
                             vbook||','||
                            
                             vstudent||','||
                             vtel||','||
                             venrolldate||','||
                             vcategory
                             );   
    end loop;   
end;

-------------------------------------------------------------------------------------------

create or replace procedure procMaSelSudangList
(
    pmonth varchar2,
    pcursor out SYS_REFCURSOR
)
is
    

begin
    
    open pcursor for 
    select 
    
    stu.student as "student",
    cat.category as "category",
    p.classdays as "classdays",
    p.total_money as "total_money",
    to_char(p.month,'mm') as mon,
    curr.curriculum as "curriculum"
    
    
    
    from tblStudent stu
        inner join tblcategory cat
        on stu.category_seq = cat.category_seq
            inner join tblenrollstudent es
            on stu.student_seq = es.student_seq
                inner join tblopencurriculum oc
                on oc.openclass_seq = es.openclass_seq
                    inner join tblcurriculum curr
                    on oc.curriculum_seq = curr.curriculum_seq
                        inner join tblpay p
                        on stu.student_seq = p.student_seq
                            where to_char(p.month,'mm') = pmonth
                                order by curriculum, category;
                                



exception
    when others then
        rollback;
end;

----------



create or replace procedure procAdmselCurriculum  
(
    presult out sys_refcursor
)
is
begin
    open presult for  
select 
    distinct
    c.curriculum_seq as curriculum_seq,
    c.curriculum as curriculum
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq =c.curriculum_seq
                          ;
exception
    when others then
    rollback;  
end;



