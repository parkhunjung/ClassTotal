--procSt.sql




commit;
rollback;


--stuentQuery.sql

-- ������ / ��� ���� �� ��� ��ȸ
--���� ���� ������ ����� �� �־�� �Ѵ�.(��� 1ȸ, ��� 1ȸ)

--��� 
--create or replace procedure procStInsAttendance
--(
--    pstudent_seq in tblattendance.student_seq%type
--)
--is
--    vstudent_seq number,
--    vattendance_status varchar2,
--    vattdate date,
--    vworkin varchar2,
--    vworkout varchar2
--    cursor stAtcursor
--    is
--    select * from tblAttendance where student_seq=vstudent_seq;
--    vresult tblAttendance%rowtype;
--    
--begin
--    
--    insert into tblAttendance (student_seq, attdate, attendance_status, workin,workout)
--    values (1, sysdate, null, 'Y', 'N');
commit;
rollback;


select * from tblAttendance where student_seq=2;

desc tblattendance;

delete from tblAttendance where to_char(attdate,'mm')=10;

update tblAttendance set attdate=default , workout='Y' , attendance_status='����' where student_seq=2 and workout is null;

insert into tblAttendance (student_seq,attdate,attendance_status,workin,workout) values ((select student_seq from tblStudent where student='������'),default,null,'Y',null);

select student_seq,student from tblStudent where student='������';
-- ����� ������Ʈ


--�ٸ� �������� ��Ȳ�� ��ȸ�� �� ����.
--��� ��� ��ȸ�� ���� ��Ȳ�� ������ �� �־�� �Ѵ�.(����, ����, ����, ����, ����, �Ἦ)
--������ ��� ��Ȳ�� �Ⱓ��(��, ��, ��)�� ��ȸ�� �� �־�� �Ѵ�.
--��

set SERVEROUTPUT ON;

create or replace procedure procStSelAttendanceDay
(
    pstudent varchar2,
    pmonth number,
    pday number,
    presult out SYS_REFCURSOR
    
)
is
    
begin
    open presult for
    select s.student_seq as "student_seq", s.student as "student", a.attdate as "attdate", a.attendance_status as "attendance_status" from tblAttendance a
        inner join tblenrollstudent e
            on a.student_seq=e.student_seq
                inner join tblStudent s
                    on e.student_seq=s.student_seq
                        where to_char(a.attdate,'mm')=pmonth and to_char(a.attdate,'dd')=pday and s.student=pstudent;
exception
    when others then
    rollback;

end;


declare
    vresult SYS_REFCURSOR;
    vstudent_seq tblStudent.student_seq%TYPE;
    vstudent tblStudent.student%type;
    vattdate tblAttendance.attdate%type;
    vattendance_status tblAttendance.attendance_status%type;
begin
    procStSelAttendanceDay('������',8,31,vresult);
    
    loop
        fetch vresult into vstudent_seq,vstudent,vattdate,vattendance_status;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent_seq||', '||vstudent||', '||vattdate||', '||vattendance_status);
    end loop;
    
end;
    

select * from tblAttendance;

select * from tblStudent;
select * from tblEnrollStudent;
--��
set SERVEROUTPUT ON;

create or replace procedure procStSelAttendanceMonth
(
    pstudent varchar2,
    pmonth number,
    presult out SYS_REFCURSOR
    
)
is
    
begin
    open presult for
    select s.student_seq as "student_seq", s.student as "student", a.attdate as "attdate", a.attendance_status as "attendance_status" from tblAttendance a
        inner join tblenrollstudent e
            on a.student_seq=e.student_seq
                inner join tblStudent s
                    on e.student_seq=s.student_seq
                        where to_char(a.attdate,'mm')=pmonth and s.student=pstudent;
exception
    when others then
    rollback;

end;


declare
    vresult SYS_REFCURSOR;
    vstudent_seq tblStudent.student_seq%TYPE;
    vstudent tblStudent.student%type;
    vattdate tblAttendance.attdate%type;
    vattendance_status tblAttendance.attendance_status%type;
begin
    procStSelAttendanceMonth('������',8,vresult);
    
    loop
        fetch vresult into vstudent_seq,vstudent,vattdate,vattendance_status;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent_seq||', '||vstudent||', '||vattdate||', '||vattendance_status);
    end loop;
    
end;

--��
set SERVEROUTPUT ON;

create or replace procedure procStSelAttendanceTotal
(
    pstudent varchar2,
    presult out SYS_REFCURSOR
    
)
is
    
begin
    open presult for
    select s.student_seq as "student_seq", s.student as "student", a.attdate as "attdate", a.attendance_status as "attendance_status" from tblAttendance a
        inner join tblenrollstudent e
            on a.student_seq=e.student_seq
                inner join tblStudent s
                    on e.student_seq=s.student_seq
                        where s.student=pstudent;
exception
    when others then
    rollback;

end;


declare
    vresult SYS_REFCURSOR;
    vstudent_seq tblStudent.student_seq%TYPE;
    vstudent tblStudent.student%type;
    vattdate tblAttendance.attdate%type;
    vattendance_status tblAttendance.attendance_status%type;
begin
    procStSelAttendanceTotal('������',vresult);
    
    loop
        fetch vresult into vstudent_seq,vstudent,vattdate,vattendance_status;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent_seq||', '||vstudent||', '||vattdate||', '||vattendance_status);
    end loop;
    
end;

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--������ / ������ ����
                            
--�������� �� �� ���� ���� ������ ��ȸ�� �� �ִ�. 

set SERVEROUTPUT ON;

create or replace procedure procStSelPay
(
    pstudent varchar2,
    presult out SYS_REFCURSOR
    
)
is
    
begin
    open presult for
    select to_char(p.month,'mm') as "month",p.total_money as "total_money" from tblPay p
        inner join tblenrollstudent e
            on p.student_seq=e.student_seq
                inner join tblStudent s
                    on e.student_seq=s.student_seq    
            where s.student=pstudent;
exception
    when others then
    rollback;

end;



declare
    vresult SYS_REFCURSOR;
    vmonth varchar2(10);
    vtotal_money tblPay.total_money%type;
begin
    procStSelPay('������',vresult);
    
    loop
        fetch vresult into vmonth,vtotal_money;
        exit when vresult%notfound;
        
        dbms_output.put_line(vmonth||', '||vtotal_money);
    end loop;
    
end;

select * from tblPay;



select s.student as "student",substr(p.month,6,2) as "month",p.total_money as "total_money" from tblPay p
    inner join tblenrollstudent e
        on p.student_seq=e.student_seq
            inner join tblStudent s
                on e.student_seq=s.student_seq    
    where substr(p.month,6,2)='08' and s.student='������';
    


create or replace procedure procStSelSudang
(
    pstudent varchar2,
    presult SYS_REFCURSOR

)
is
begin
    open presult for
    select
        

-------------------------------------------------------------------------------------------------------
--�������� ���� ���� (������, ���� �Ⱓ, ���ǽ�)�� Ȯ���� �� �ִ�.
--�ߵ� Ż�� ���θ� Ȯ���� �� �ִ�.

select * from tblStudent;
--
--create or replace procedure procStSelSugang
--(
--    pstudent varchar2,
--    presult out sys_refcursor
--)
--is
--begin
--    open presult for
--    select  
--        st.student as "student",
--        c.curriculum as "curriculum",
--        o.curriculum_start as "curriculum_start",
--        o.curriculum_end as "curriculum_end",
--        classr.classroom as "classroom",
--        s.sugang_status as "sugang_status",
--        case
--            when e.finish_status='������' then '������'
--            when e.finish_status='��������' then '����'
--            when e.finish_status='�ߵ�Ż��' then '�ߵ�Ż��'
--        end as "���� ����" 
--    from tblSugang s
--        inner join tblEnrollStudent e
--            on s.student_seq=e.student_seq
--                inner join tblStudent st
--                    on st.student_seq=s.student_seq
--                        inner join tblOpenCurriculum o
--                            on o.openclass_seq=e.openclass_seq
--                                inner join tblCurriculum c
--                                    on o.openclass_seq=c.curriculum_seq
--                                        inner join tblclassroom classr
--                                            on o.classroom_seq = classr.classroom_seq
--                                        where st.student=pstudent;
--    exception
--        when others then
--        rollback;
--end;
--
--
--
--
--declare
--    vresult sys_refcursor;
--    vstudent tblstudent.student%type;
--    vcurriculum tblCurriculum.curriculum%type;
--    vcurriculum_start tblOpenCurriculum.curriculum_start%type;
--    vcurriculum_end tblOpenCurriculum.curriculum_end%type;
--    vclassroom tblClassroom.classroom%type;
--    vsugang_status varchar2(100);
--    vfinish_status varchar2(100);
--begin
--    procStSelSugang('������',vresult);
--    loop
--        fetch vresult into vstudent,vcurriculum,vcurriculum_start,vcurriculum_end,vclassroom,vsugang_status,vfinish_status;
--        exit when vresult%notfound;
--        
--        dbms_output.put_line(vstudent||', '||vcurriculum||', '||vcurriculum_start||', '||vcurriculum_end||', '||vclassroom||', '||vsugang_status||','||vfinish_status);
--    
--    end loop;
--end;
------------------------------------------------------------------------
--�������� ���� ����(������,���۳�¥,���ᳯ¥,���ǽ�)
create or replace procedure procStSelSugang
(
    pstudent varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select  
        c.curriculum_seq as "curriculum_seq",
        c.curriculum as "curriculum",
        o.curriculum_start as "curriculum_start",
        o.curriculum_end as "curriculum_end",
        classr.classroom as "classroom"
    from tblSugang s
        inner join tblEnrollStudent e
            on s.student_seq=e.student_seq
                inner join tblStudent st
                    on st.student_seq=s.student_seq
                        inner join tblOpenCurriculum o
                            on o.openclass_seq=e.openclass_seq
                                inner join tblCurriculum c
                                    on o.openclass_seq=c.curriculum_seq
                                        inner join tblclassroom classr
                                            on o.classroom_seq = classr.classroom_seq
                                        where st.student=pstudent;
    exception
        when others then
        rollback;
end;




declare
    vresult sys_refcursor;
    vcurriculum_seq tblCurriculum.curriculum_seq%type;
    vcurriculum tblCurriculum.curriculum%type;
    vcurriculum_start tblOpenCurriculum.curriculum_start%type;
    vcurriculum_end tblOpenCurriculum.curriculum_end%type;
    vclassroom tblClassroom.classroom%type;
begin
    procStSelSugang('������',vresult);
    loop
        fetch vresult into vcurriculum_seq,vcurriculum,vcurriculum_start,vcurriculum_end,vclassroom;
        exit when vresult%notfound;
        
        dbms_output.put_line(vcurriculum_seq||', '||vcurriculum||', '||vcurriculum_start||', '||vcurriculum_end||', '||vclassroom);
    
    end loop;
end;
------------------------------------------------------------------------
--�������� ������ ��������(��ȣ,�����,���۳�¥,���ᳯ¥)



create or replace procedure procStSelSubject
(
    pstudent varchar2,
    presult out sys_refcursor
)
is
begin
    open presult for
    select distinct  s.subject_seq as "subject_seq",s.subject as "subject", os.subject_start as "subject_start", os.subject_end as "subject_end"
        from tblSubject s 
            inner join tblAbleSubject asj
                on asj.subject_seq=s.subject_seq
                    inner join tblOpenSubject os
                        on os.subject_seq =asj.subject_seq
                            inner join tblOpenCurriculum oc
                                on oc.openclass_seq=os.openclass_seq
                                    inner join tblEnrollStudent es
                                        on es.openclass_seq=oc.openclass_seq
                                            inner join tblStudent st
                                                on st.student_seq=es.student_seq
                                                            where st.student=pstudent order by s.subject_seq;
    exception
        when others then
        rollback;
end;




declare
    vresult sys_refcursor;
    vsubject_seq number;
    vsubject varchar2(100);
    vsubject_start date;
    vsubject_end date;
begin
    procStSelSubject('������',vresult);
    loop
        fetch vresult into vsubject_seq,vsubject,vsubject_start,vsubject_end;
        exit when vresult%notfound;
        
        dbms_output.put_line(vsubject_seq||','||vsubject||', '||vsubject_start||', '||vsubject_end);
    
    end loop;
end;




------------------------------------------------------------------------
--�������� ������ ���� ���� �� ���θ� Ȯ���� �� �ִ�.
create or replace procedure procStSelTeacherScore
(
    pstudent_seq number,
    presult out SYS_REFCURSOR
)
is
begin
    open presult for
    select distinct st.student as "student", c.curriculum as "curriculum", s.subject as "subject",t.teacher as "teacher",
            case
                when ts.point is not null then '�� �Ϸ�'
                when ts.point is null then '�� �̿Ϸ�'
            end as "point"
    from tblEnrollStudent e
        inner join tblTeacherScore ts
            on e.student_seq=ts.student_seq
                inner join tblOpenCurriculum oc
                    on oc.classroom_seq=e.classroom_seq
                        inner join tblCurriculum c
                            on c.curriculum_seq=oc.curriculum_seq
                                inner join tblOpenSubject os
                                    on os.openclass_seq=oc.openclass_seq
                                        inner join tblSubject s
                                            on s.subject_seq=os.subject_seq
                                                inner join tblTeacher t
                                                    on t.teacher_seq=os.teacher_seq
                                                        inner join tblStudent st
                                                            on e.student_seq=st.student_seq
                                                        where st.student_seq = pstudent_seq;
exception
    when others then
    rollback;
end;


declare
    vresult SYS_REFCURSOR;
    vstudent tblStudent.student%type;
    vcurriculum tblCurriculum.curriculum%type;
    vsubject tblSubject.subject%type;
    vteacher tblTeacher.teacher%type;
    vpoint varchar2(50);
begin
    procStSelTeacherScore(10,vresult);
    
    loop
        fetch vresult into vstudent,vcurriculum,vsubject,vteacher,vpoint;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent||', '||vcurriculum||', '||vsubject||', '||vteacher||', '||vpoint);
    end loop;
end;


select * from tblteacherscore;


--�������׸� ��ȸ

set SERVEROUTPUT ON;


create or replace procedure procStSelEva
(
    pstudent_seq number,
    popenclass_seq number,
    psubject_seq number,
    presult out SYS_REFCURSOR
)
is
begin
    open presult for
    select distinct e.score_seq,e.evaluation
        from tblEvaluation e 
            inner join tblTeacherScore ts
                on e.score_seq=ts.score_seq
                    inner join tblOpenSubject os
                        on os.openclass_seq=ts.openclass_seq
                            inner join tblAbleSubject asj
                                on asj.subject_seq=os.subject_seq
                                    inner join tblSubject s
                                        on s.subject_seq=asj.subject_seq
                                            where ts.student_seq=10  and ts.openclass_seq=1 and s.subject_seq=1
                                            order by e.score_seq asc;
exception
    when others then
    rollback;
end;



declare 
    vresult SYS_REFCURSOR;
    vscore_seq tblEvaluation.score_seq%type;
    vevaluation tblEvaluation.evaluation%type;
    
begin procStSelEva(10,1,1,vresult);

        loop
        fetch vresult into vscore_seq,vevaluation;
        exit when vresult%notfound;
        
        dbms_output.put_line(vscore_seq||'. '||vevaluation);
    end loop;
end;




select e.score_seq,e.evaluation from tblEvaluation e
    inner join tblTeacherScore ts
        on e.score_seq=ts.score_seq
            where ts.subject_seq=1 and ts.openclass_seq=1;
            
            
select * from tblTeacherScore; 
select * from tblStudent;

--���� ��

rollback;
commit;

update tblTeacherScore set point=? where score_seq=1;
update tblTeacherScore set point=? where score_seq=2;
update tblTeacherScore set point=? where score_seq=3;
update tblTeacherScore set point=? where score_seq=4;
update tblTeacherScore set point=? where score_seq=5


create or replace procedure procStUpdTeacherScore
(
    popenclass_seq number,
    psubject_seq number,
    pstudent_seq number,
    pa1 number,
    pa2 number,
    pa3 number,
    pa4 number,
    pa5 number,
    presult out SYS_REFCURSOR

)
is
begin
    update tblTeacherScore set point=pa1 where score_seq=1 and openclass_seq=popenclass_seq and subject_seq=psubject_seq and student_seq = pstudent_seq;
    update tblTeacherScore set point=pa2 where score_seq=2 and openclass_seq=popenclass_seq and subject_seq=psubject_seq and student_seq = pstudent_seq;
    update tblTeacherScore set point=pa3 where score_seq=3 and openclass_seq=popenclass_seq and subject_seq=psubject_seq and student_seq = pstudent_seq;
    update tblTeacherScore set point=pa4 where score_seq=4 and openclass_seq=popenclass_seq and subject_seq=psubject_seq and student_seq = pstudent_seq;
    update tblTeacherScore set point=pa5 where score_seq=5 and openclass_seq=popenclass_seq and subject_seq=psubject_seq and student_seq = pstudent_seq;
    
exception
    when others then
    rollback;
end; 


declare     


    
--------------------------------------------------------------------------------------------------------------------------------

/* ���� ��ȸ */

--������ / ���� ��ȸ

--���� ���� / ���� ��ȣ, �����, ���� �Ⱓ(����~��), �����, �����, ���� ���� ���� (���,�ʱ�,�Ǳ��� ����)
--                  ���� ���� ����(���, �ʱ�, �Ǳ��� ����), ���� ���� ��¥, ���� ���� ����

--���� / �������� �� ���� �������� ����ؼ� �����ߴٰ� �����Ѵ�.
--          �� ���� ���� ������ ���� ���� ������ �����Ѵٰ� �����Ѵ�.
--          ���� �Ⱓ�� ������ ���� ������ �Ǵ� �ߵ� Ż�� ó���� �������� ��� �Ϻ� ���� �����ߴٰ� �����Ѵ�.

--���� ������ ���� ��� ���·� ��µȴ�

set SERVEROUTPUT ON;

create or replace procedure procStSelGrade
(
    pstudent varchar2,
    psubject_seq number,
    presult out SYS_REFCURSOR
)
is
begin
    open presult for
    select distinct s.subject_seq as "subject_seq",
                s.subject as "subject",
                g.attendance as "attendance",
                g.written_exam as "written_exam",
                g.skill_test as "skill_test"
    from tblGrade g
        inner join tblEnrollStudent es
            on g.student_seq=es.student_seq
                inner join tblStudent st
                    on es.student_seq=st.student_seq
                        inner join tblOpenCurriculum oc
                            on oc.openclass_seq = es.openclass_seq
                                inner join tblOpenSubject os
                                    on os.openclass_seq=oc.openclass_seq
                                        inner join tblAbleSubject asj
                                            on asj.subject_seq=os.subject_seq
                                                inner join tblSubject s
                                                    on s.subject_seq=asj.subject_seq
                                                        where st.student=pstudent
                                                            and s.subject_seq=psubject_seq
                                                            order by s.subject_seq;
                                        
                            
    exception
        when others then
        rollback;
end;


declare
    vresult SYS_REFCURSOR;
    vsubject_seq tblSubject.subject_seq%type;
    vsubject tblSubject.subject%type;
    vattendance tblGrade.attendance%type;
    vwritten_exam tblGrade.written_exam%type;
    vskill_test tblGrade.skill_test%type;
    
begin
    procStSelGrade('������',1,vresult);
    
    loop
        fetch vresult into vsubject_seq,vsubject,vattendance,vwritten_exam,vskill_test;
        exit when vresult%notfound;
        
        dbms_output.put_line(vsubject_seq||','||vsubject||', '||vattendance||', '||
                            vwritten_exam||', '||vskill_test);
    end loop;
    
end;
        
                                                                                       
 select * from tblTeacherScore;
 select * from tblPoint;
 select * from tblGrade;
 delete from tblTeacherScore;
--������ ��ϵ��� ���� ������ ������ ��µǰ� ������ null������ ��µǵ��� �Ѵ�.    !!!@@ ����  --�������
create or replace procedure procStSelSubjectGrade
(
    psubject_seq number,
    presult out SYS_REFCURSOR

)
is
begin 
    open presult for
    select st.student as "student",o.subject_seq,s.subject as "subject",
        case
            when g.attendance is not null then g.attendance
            when g.attendance is null then null
        end as "attendance",
        case
            when g.written_exam is not null then g.written_exam
            when g.written_exam is null then null
        end as "written_exam",
        case
            when g.skill_test is not null then g.skill_test
            when g.skill_test is null then null
        end as "skill_test"
    from tblGrade g
        inner join tblEnrollStudent e
            on g.student_seq=e.student_seq
                inner join tblOpenSubject o
                    on o.openclass_seq=e.openclass_seq
                        inner join tblSubject s
                            on s.subject_seq=o.subject_seq
                                inner join tblStudent st
                                    on st.student_seq=e.student_seq
                                        where  o.subject_end<sysdate and o.subject_seq=psubject_seq;
    
    exception
        when others then
            rollback;
end;

declare
    vresult SYS_REFCURSOR;
    vstudent tblStudent.student%type;
    vsubject_seq tblSubject.subject%type;
    vsubject tblSubject.subject%type;
    vattendance varchar2(100);
    vwritten_exam varchar2(100);
    vskill_test varchar2(100);
    
begin
    procStSelSubjectGrade(20,vresult);
    
    loop
        fetch vresult into vstudent,vsubject_seq,vsubject,vattendance,vwritten_exam,vskill_test;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent||','||vsubject_seq||','||vsubject||','||vattendance||','||vwritten_exam||','||vskill_test);
    
    
    end loop;
    
end;
    
set SERVEROUTPUT ON;                         

select * from tblgrade order by student_seq, test_seq;
select * from tbltest;
select * from tblOpenCurriculum;
select * from tblOpenSubject;


-------------------------------------------------------------------------------------------------------------------------------
/* ���� �� */
-- ������ / ���� ��

-------->>>>>>>>>>JDBC

--�������� ����� ���� ���Ͽ� ���� �򰡸� �����Ѵ�. @@@@ ����

select * from tblTeacherScore ts
    inner join tblEvaluation e
        on e.score_seq = ts.score_seq
            inner join 
            

select * from tblEvaluation;


select score_seq,evaluation from tblEvaluation where score_seq=1;










--5���� �׸� ���Ͽ� ���� �򰡸� �����Ѵ�.
select t.student_seq as "student_seq",
            t.score_seq as "score_seq", 
            e.evaluation as "evaluation",
            t.point as "point"
            
                        from tblTeacherScore t
                            inner join tblEvaluation e
                                on e.score_seq = t.score_seq; --5�� �׸� ������

--�� �׸��� 1��~5������ (1�� ����) ������ �Է¹޴´�.
select t.student_seq as "student_seq", t.score_seq as "score_seq",e.evaluation as "evaluation",t.point as "point" from tblEvaluation e
    inner join tblTeacherScore t
        on t.score_seq = e.score_seq;

--insert into tblTeacherScore(point) values 2; --���� ����


--������ �����Ͽ� 5���� �׸����� ����� ����,  @ ���� ����
select  sum(ts.point) as "point" from tblTeacherScore ts
                            inner join tblEvaluation e
                                on e.score_seq = ts.score_seq
                                inner join tblOpenSubject os
                                    on os.subject_seq=ts.subject_seq
                                        inner join tblTeacher t
                                            on t.teacher_seq=os.teacher_seq
                                                inner join tblEnrollStudent es
                                                    on es.student_seq=ts.student_seq
                                                        where ts.openclass_seq=1 and ts.subject_seq=1 and os.class_status is not null;
                                                            group by ts.score_seq order by ts.score_seq asc;
 
select * from tblTeacherScore;
es.student_seq, ts.openclass_seq, ts.subject_seq,os.teacher_seq, 
 
 
-- ��� �������� ��� ������ �����Ͽ� ���� ����� ����.      @                              
select t.student_seq as "student_seq", avg(t.point) as "point" from tblTeacherScore t
                            inner join tblEvaluation e
                                on e.score_seq = t.score_seq
                                    group by t.student_seq  order by t.student_seq  asc;
                                    
                                    
--------------------------------------------------------------------------------------------------------------------------------------------------------------



commit;

select * from tblEvaluation;

select * from tblopensubject;
select * from tblCurriculum;

select * from tblopenCurriculum;
select * from tblSubject;
select t.teacher from tblOpenCurriculum oc
    inner join tblOpenSubject os
        on oc.openclass_seq=os.openclass_seq
            inner join tblTeacher t
                on os.teacher_seq=t.teacher_seq
                    inner join tblAbleSubject as
                        on t.teacher_seq=as.teacher_seq
                    
                            where oc.curriculum_seq=1;

select * from tblTeacher;


select * from tblevaluation;

select * from tblStudent;

--�ڽ��� ���� ��ȸ
create or replace procedure procStSelStudent
(
    pstudent varchar2,
    presult out SYS_REFCURSOR
)
is
    
begin
    open presult for
    select student,ssn,tel,enrolldate,
    case
        when category_seq=1 then '�Ϲ�'
        when category_seq=2 then '�뼺��'
    end "category_seq"
    from tblStudent
        where student=pstudent;
exception
    when others then
    rollback;

end;

declare
    vresult SYS_REFCURSOR;
    vstudent tblStudent.student%type;
    vssn tblStudent.ssn%type;
    vtel tblStudent.tel%type;
    venrolldate tblStudent.enrolldate%type;
    vcategory_seq varchar2(50);

    
begin
    procStSelStudent('������',vresult);
    
    loop
        fetch vresult into vstudent,vssn,vtel,venrolldate,vcategory_seq;
        exit when vresult%notfound;
        
        dbms_output.put_line(vstudent||','||vssn||','||vtel||','||venrolldate||','||vcategory_seq); 
    
    end loop;
    
end;


commit;

set serveroutput on;







select * from tblStudent;
select * from tblTeacher;
select * from tblManager;