package com.test.util;

import java.util.Scanner;

public class UI {

	// 교육생 로그인/교사 로그인/관리자 로그인 에 붙일 바
	public static void titleBar() {
		for (int i = 0; i < 20; i++) {
			System.out.print("☆★");
		}
	}
	
	// 소제목에 붙일 바
	public static void bar() {
		for (int i = 0; i < 20; i++) {
			System.out.print("--");
		}
	}
	
	// 리스트 제목에 붙일 바
	public static void listBar(){
		for (int i = 0; i < 20; i++) {
			System.out.print("==");
		}
	}

	// 잠시 멈춤
	public static void pause() {
		System.out.println("뒤로 돌아가려면 아무 키나 눌러주세요.");
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
	}

	public static void pause(String label) {
		System.out.println(label);
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
	}
	
	public static void inputPause() {
		System.out.print("입력한 내용이 맞습니까?(y/n):");
	}
	
	public static void deletePause() {
		System.out.print("정말 삭제하시겠습니까?(y/n):");
	}
	
	// 추가,수정,삭제 완료시 메세지 출력 
	public static void completeMessage(String label) {
		System.out.printf("%s (이)가 완료되었습니다.",label);
	}
	
	public static void baseSelectOption(String label) { 
		System.out.printf("0.돌아가기  *.처음으로\t\t선택(%s번호):",label);
	}

	
	// 메뉴 출력
	public final static String[] LOGIN = {"관리자 로그인","교사 로그인","교육생 로그인"};
	public final static String[] ADMIN_MENU = {"기초 정보 관리","계정 관리","출결 조회","시험 관리","평가 조회"};
	public final static String[] ADMIN_BASEINFO = {"과정 관리","자재 관리"};
	public final static String[] ADMIN_BASEINFO_COURSEINFO = {"강의실","과목","교사","교재"};
	public final static String[] ADMIN_BASEINFO_COURSEINFO_SUBJECT = {"과목 리스트","과목 등록","과목 삭제","과목 정보 수정"};
	public final static String[] ADMIN_BASEINFO_COURSEINFO_INSTRUCTOR = {"과목별 수업 가능 교사 리스트","과목별 수업 가능 교사 추가","과목별 수업 가능 교사 삭제"};
	public final static String[] ADMIN_BASEINFO_COURSEINFO_TEXTBOOK = {"교재 목록","교재 추가","교재 삭제"};
	public final static String[] ADMIN_BASEINFO_MATERIAL = {"자재 현황 조회","자재 현황 갱신"};
	public final static String[] ADMIN_BASEINFO_MATERIAL_SELECT = {"자재별 목록 조회","자재 현황 갱신"};
	public final static String[] ADMIN_ACCOUNT = {"교사 계정 관리","교육생 계정 관리"};
	public final static String[] ADMIN_ACCOUNT_INSTRUCTOR = {"교사계정 추가","교사계정 삭제","교사계정 전체목록 조회","교사계정 검색"};
	public final static String[] ADMIN_ACCOUNT_INSTRUCTOR_SELECT = {"이름","과정","강의 가능 과목"};
	public final static String[] ADMIN_ACCOUNT_STUDENT = {"교육생계정 추가","교육생계정 삭제","교육생계정 전체 목록조회","교육생 계정 검색"};
	public final static String[] ADMIN_ACCOUNT_STUDENT_SELECT = {"이름","과정","수료 여부"};
	public final static String[] ADMIN_ATTENDANCE = {"과정 기간별 출결 조회","교육생 기간별 출결 조회"};
	public final static String[] ADMIN_EXAM  = {"개설 과목 정보 출력"};	
	public final static String[] ADMIN_EVALUTION = {"과정 평가 조회","교사 평가 조회"};
	
	public final static String[] STUDENT_MENU = {"교육생 계정정보","출결조회","평가 등록"};
	public final static String[] STUDENT_ACCOUNT = {"자기 정보 조회","성적 조회","이수 과정 조회"};
	public final static String[] STUDENT_ATTENDANCE = {"기간별 출결조회","과목 선택 조회","근태 상황별 조회"};
	public final static String[] STUDENT_ATTENDANCE_PERIOD = {"연도별 조회","월별 조회","일별 조회"};
	public final static String[] STUDENT_ATTENDANCE_SITUATION = {"지각 기록 조회","병가 기록 조회","조퇴 기록 조회"};
	public final static String[] STUDENT_REGISTEREVALUTION = {"교사 평가","과정 평가"};
	
	public final static String[] INSTRUCTOR_MENU = {"강의 스케줄 조회","배점 입출력","성적 입출력","출결 조회","교사 평가 조회"};
	public final static String[] INSTRUCTOR_SCHEDULE = {"강의 예정","강의 중","종료된 강의"};
	public final static String[] INSTRUCTOR_SCORING = {"출결배점","필기배점","실기배점","시험날짜","시험문제"};
	public final static String[] INSTRUCTOR_GRADE = {"성적 입력","성적 조회"};
	public final static String[] INSTRUCTOR_GRADE_SELECT = {"과목별 조회","교육생별 조회","학생비율통계 조회"};
	
	public final static String[] INSTRUCTOR_ATTENDANCE = {"기간별 조회","과목 선택 조회","인원 선택 조회"};
	public final static String[] INSTRUCTOR_ATTENDANCE_PERIOD = {"월별 조회","일별 조회"};
	
	
	public static void menu(String[] list) {

		for (int i = 0; i < list.length; i++) {
			System.out.printf("%d. %s\n", (i + 1), list[i]);
		}
		System.out.println();
	}

	// 테이블 출력 > 헤더 출력
	public static void header(String[] labels) {
		for (String label : labels) {
			System.out.printf("[%s]\t", label);
		}
		System.out.println();
	}

	// 테이블 출력 > 데이터 출력
	public static void data(Object[] datas) {
		for (Object data : datas) {
			System.out.printf("%s\t", data);
		}
		System.out.println();
	}

	// 결과 메시지 출력
	public static void result(String msg) {
		System.out.printf("결과]" + msg);
		System.out.println();
	}

	public static void result(int result, String msg) {
		if (result > 0) {
			System.out.printf("결과]" + msg);
		} else {
			System.out.println("실패했습니다. 관리자에게 문의하세요.");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		baseSelectOption("강의실");
	}

}
