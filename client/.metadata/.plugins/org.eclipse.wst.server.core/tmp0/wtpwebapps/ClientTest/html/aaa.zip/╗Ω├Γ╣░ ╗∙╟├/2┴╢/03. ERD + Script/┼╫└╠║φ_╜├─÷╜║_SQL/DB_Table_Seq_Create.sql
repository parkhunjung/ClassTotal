-- Db_Seq_Create.sql

-- ALTER TABLE tblPay DROP CONSTRAINT '�������Ǹ�';

-- sequence
create sequence Curriculum_Seq
    start with 31; -- ����
create sequence Subject_Seq
    start with 33; -- ����
create sequence ClassRoom_Seq
    start with 37; -- ���ǽ�
create sequence Book_Seq
    start with 32; -- ����
create sequence Manager_Seq
    start with 4; -- ������
create sequence Teacher_Seq
    start with 11; -- ����
create sequence Student_Seq
    start with 101; -- ������
create sequence Test_Seq
    start with 14; -- ����
create sequence Incentive_Seq
    start with 2; -- �μ�Ƽ���ȣ
create sequence Category_Seq
    start with 3; -- ī�װ���(����������)
create sequence Score_Seq
    start with 6; -- ���׸�
create sequence Openclass_Seq
    start with 7; -- ��������

commit;

drop sequence Curriculum_Seq; -- ����
drop sequence Subject_Seq; -- ����
drop sequence ClassRoom_Seq; -- ���ǽ�
drop sequence Book_Seq; -- ����
drop sequence Manager_Seq; -- ������
drop sequence Teacher_Seq; -- ����
drop sequence Student_Seq; -- ������
drop sequence Test_Seq; -- ����
drop sequence Incentive_Seq; -- �μ�Ƽ���ȣ
drop sequence Category_Seq; -- ī�װ���(����������)
drop sequence Score_Seq; -- ���׸�
drop sequence Openclass_Seq; -- ��������


drop table tblBook;
drop table tblCurriculum;
drop table tblTeacher;
drop table tblSubject;
drop table tblManager;
drop table tblStudent;
drop table tblBasicOption;
drop table tblCategory;

-- table
-- ����
create table tblBook
(

    book_seq number primary key,
    book varchar2(100) not null,
    publisher varchar2(50) not null


);

-- ��������
create table tblCurriculum
(

    curriculum_seq number primary key,
    curriculum varchar2(300) not null

);

-- ����
create table tblTeacher
(

    teacher_seq number primary key,
    teacher varchar2(50) not null,
    ssn varchar2(20) not null,
    tel varchar2(50) null
);

-- ����
create table tblSubject
(

    subject_seq number primary key,
    subject varchar2(200) not null
);


-- ������
create table tblManager
(

    manager_seq number primary key,
    manager varchar2(50) not null,
    ssn varchar2(20) not null,
    tel varchar2(50) null
);

-- ������
create table tblStudent
(
    student_seq number primary key,
    student varchar2(50) not null,
    ssn varchar2(20) not null,
    tel varchar2(50) null,
    enrolldate date default sysdate,
    category_seq number references tblcategory(category_seq) not null

);


commit;

-- ��������(�μ�Ƽ�� �ݾ�)
create table tblBasicOption
(
    incentive_seq number primary key,
    incentive number default 500000
);



-- ī�װ���(�л�����)
create table tblCategory
(
    category_seq number primary key,
    category varchar2(50) not null,
    day_pay number not null
);


-- ���׸�
create table tblEvaluation
(

    score_seq number primary key not null,
    evaluation varchar2(300) not null

);


--------------------------------------------- �ܷ�Ű ����

-- ���ǽ�
create table tblClassRoom
(

    classroom_seq number primary key,
    manager_seq number references tblManager(manager_seq) not null,
    classroom varchar2(200) not null,
    capacity number not null
    

);



-- ���� ���� ����
create table tblAbleSubject
(    

    teacher_seq number not null,
    subject_seq number not null,
    
    constraint tblAbleSubject_t_seq_fk
        foreign key(teacher_seq)
            references tblTeacher(teacher_seq),
            
    constraint tblAbleSubject_s_seq_fk
        foreign key(subject_seq)
            references tblSubject(subject_seq),   
            
    constraint tblAbleSubject_seq_pk
        primary key(teacher_seq,subject_seq)
    

);


select * from tblenrollstudent;
-- ���� ���� ����
create table tblOpenCurriculum
(
    openclass_seq number primary key,
    curriculum_seq number null,
    curriculum_start date default sysdate not null,
    curriculum_end date default sysdate not null,
    classroom_seq number references tblClassRoom(classroom_seq) not null,
    subject_status varchar2(10) not null,
    enrollment number not null,
    
    constraint tbl_cur_seq_fk
        foreign key(curriculum_seq)
            references tblCurriculum(curriculum_seq)

);


-- ��� ������ ����

create table tblEnrollStudent
(
    
    student_seq number primary key,
    openclass_seq number references tblOpenCurriculum(openclass_seq) null,
    classroom_seq number references tblClassRoom(classroom_seq) null,
    finish_status varchar2(50) null,
    p_np_date date default sysdate null,
    
    constraint tblEnrollStudent_stu_seq_fk
        foreign key(student_seq)
            references tblStudent(student_seq)

);

    
    

-- ���� ��û & ����
create table tblSugang
(
    enroll_seq number primary key,
    student_seq number references tblEnrollStudent(student_seq) not null,
    openclass_seq number references tblOpenCurriculum(openclass_seq) not null,
    sugang_status varchar2(50) not null

);

-- ������
create table tblAttendance
(
    student_seq number references tblEnrollStudent(student_seq) not null,
    attDate date default sysdate not null ,
    attendance_status varchar2(20) null,
    workin varchar2(3) null,
    workout varchar2(3) null

);

select * from tblAttendance;

alter table tblAttendance
    modify(workin varchar2(3) null);
    
alter table tblAttendance
    modify(workout varchar2(3) null);
    
commit;

select * from tblSugang;

-- ������ ����
create table tblPay
(

    student_seq number references tblEnrollStudent(student_seq) not null,
    classdays number null ,
    total_money number null,
    month date default sysdate null


);

select * from tblPay;

-- ���� ���� ����
create table tblOpenSubject
(
    subject_seq number not null,
    openclass_seq number ,
    book_seq number references tblBook(book_seq) null,
    teacher_seq number not null,
    subject_start date default sysdate null,
    subject_end date default sysdate null,
    class_status varchar2(50) null,
    
    constraint tblOpenSubject_sub_tea_seq_fk
        foreign key(subject_seq, teacher_seq)
            references tblablesubject(subject_seq, teacher_seq),
            
    constraint tblOpenSubject_cur_seq_fk
        foreign key(openclass_seq)
            references tblOpenCurriculum(openclass_seq),
            
    constraint tblOpenSubject_cur_seq_pk
        primary key(subject_seq,openclass_seq)

);

commit;

-- ���� ��
create table tblTeacherScore
(
    subject_seq number not null,
    openclass_seq number not null,
    student_seq number references tblEnrollStudent(student_seq),
    score_seq number references tblEvaluation(score_seq),
    point number null,
    
    constraint tblTeacherScore_so_seq_fk
        foreign key(subject_seq, openclass_seq)
            references tblOpenSubject(subject_seq, openclass_seq),
            
    constraint tblTeacherScore_cur_seq_fk
        foreign key(openclass_seq)
            references tblOpenCurriculum(openclass_seq)

);


commit;

-- ����
create table tblTest
(
    test_seq number primary key not null,
    openclass_seq number  not null,
    subject_seq number not null,
    
    constraint tblTest_seq_fk
        foreign key(openclass_seq,subject_seq)
            references tblOpenSubject(openclass_seq,subject_seq)

);


-- ����
create table tblGrade
(
    student_seq number not null,
    attendance number null,
    written_exam number null,
    skill_test number null,
    test_seq number null,
    
    constraint tblGrade_stu_seq_fk
        foreign key(student_seq)
            references tblEnrollStudent(student_seq),
    
    constraint tblGrade_test_seq_fk
        foreign key(test_seq)
            references tblTest(test_seq),
            

    constraint tblGrade_seq_pk
        primary key(student_seq)

);




-- ����
create table tblPoint
(
    test_seq number primary key not null,
    attendance number null,
    written_exam number null,
    skill_test number null,
    
    constraint tblPoint_seq_pk
        foreign key(test_seq)
            references tblTest(test_seq)

);

-- ���蹮��
create table tblTestQuestion
(
    test_seq number not null,
    question varchar2(600) null,
    
    constraint tblTestQuestion_seq_fk
        foreign key(test_seq)
            references tblTest(test_seq)

);



-- ���賯¥
create table tblTestDate
(
    test_seq number primary key not null,
    testDate date null,
    
    constraint tblTestDate_seq_fk
        foreign key(test_seq)
            references tblTest(test_seq)

);


-- ���� �μ�Ƽ��
create table tblTeacherBonus
(
    subject_seq number not null,
    openclass_seq number  not null,
    incentive_seq number not null,
    
    constraint tbl_double_seq_fk
        foreign key(subject_seq,openclass_seq)
            references tblOpenSubject(subject_seq,openclass_seq),
            
    constraint tbl_incen_seq_fk
        foreign key(incentive_seq)
            references tblBasicOption(incentive_seq)

);


-- ���� ���蹮�� ���� ��Ͽ���
create table tblSubjectTestStatus
(
    subject_seq number not null,
    openclass_seq number  not null,
    test_status varchar2(3) not null,
    
    constraint tblSubjectTestStatus_seq_fk
        foreign key(subject_seq,openclass_seq)
            references tblOpenSubject(subject_seq,openclass_seq),
            
    constraint tblSubjectTestStatus_seq_pk
        primary key(subject_seq,openclass_seq)

);

-- ���� ���� ��Ͽ���
create table tblSubjectGradeStatus
(
    subject_seq number not null,
    openclass_seq number  not null,
    grade_status varchar2(3) not null,
    
    constraint tblSubjectGradeStatus_seq_fk
        foreign key(subject_seq,openclass_seq)
            references tblOpenSubject(subject_seq,openclass_seq),
            
    constraint tblSubjectGradeStatus_seq_pk
        primary key(subject_seq,openclass_seq)

);



commit;


DROP TABLE tblOpenSubject CASCADE CONSTRAINT;
DROP TABLE tblTeacherBonus CASCADE CONSTRAINT;
DROP TABLE tblSubjectTestStatus CASCADE CONSTRAINT;
DROP TABLE tblSubjectGradeStatus CASCADE CONSTRAINT;
DROP TABLE tblPoint CASCADE CONSTRAINT;
DROP TABLE tblTest CASCADE CONSTRAINT;
DROP TABLE tblTestQuestion CASCADE CONSTRAINT;
DROP TABLE tblTestDate CASCADE CONSTRAINT;
DROP TABLE tblGrade CASCADE CONSTRAINT;
DROP TABLE tblTeacherScore CASCADE CONSTRAINT;


DROP TABLE tblSubjectGradeStatus CASCADE CONSTRAINT;
DROP TABLE tblSubjectTestStatus CASCADE CONSTRAINT;
DROP TABLE tblTeacherBonus CASCADE CONSTRAINT;
DROP TABLE tblTestDate CASCADE CONSTRAINT;
DROP TABLE tblTestQuestion CASCADE CONSTRAINT;
DROP TABLE tblPoint CASCADE CONSTRAINT;
DROP TABLE tblTest CASCADE CONSTRAINT;
DROP TABLE tblGrade CASCADE CONSTRAINT;
DROP TABLE tblTeacherScore CASCADE CONSTRAINT;
DROP TABLE tblOpenSubject CASCADE CONSTRAINT;
DROP TABLE tblPay CASCADE CONSTRAINT;
DROP TABLE tblAttendance CASCADE CONSTRAINT;
DROP TABLE tblSugang CASCADE CONSTRAINT;
DROP TABLE tblEnrollStudent CASCADE CONSTRAINT;
DROP TABLE tblOpenCurriculum CASCADE CONSTRAINT;
DROP TABLE tblAbleSubject CASCADE CONSTRAINT;
DROP TABLE tblClassRoom CASCADE CONSTRAINT;


