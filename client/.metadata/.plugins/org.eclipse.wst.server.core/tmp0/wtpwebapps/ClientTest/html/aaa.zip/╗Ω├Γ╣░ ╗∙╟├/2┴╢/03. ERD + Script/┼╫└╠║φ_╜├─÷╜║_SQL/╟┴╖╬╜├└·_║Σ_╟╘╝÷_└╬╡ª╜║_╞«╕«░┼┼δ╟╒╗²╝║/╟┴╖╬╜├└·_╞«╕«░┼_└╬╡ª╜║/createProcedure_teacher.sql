--��2
--���ν���2
--Ʈ����2
--�ε���2

set SERVEROUTPUT on;

-- Ư�� ������ ������ ��ȸ�Ѵ�.
create or replace procedure procTeselTe
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    
begin
    open presult for 
    select * from tblteacher where teacher=pteacher;

exception
    when others then
    rollback;  
end;
--desc tblteacher;
--ȣ��
declare
    vresult sys_refcursor;
    vteacher_seq tblteacher.teacher_seq%type;
    vteacher tblteacher.teacher%type;
    vssn tblteacher.ssn%type;
    vtel tblteacher.tel%type;
begin
    procTeselTe('�ջ��',vresult);
    
    loop
        fetch vresult into vteacher_seq,vteacher,vssn,vtel;
        exit when vresult%notfound;
        dbms_output.put_line(vteacher_seq||','||
                             vteacher ||','||
                             vssn||','||
                             vtel);
    end loop;
end;

--Ư�� ������ ���� �������� Ȯ���Ѵ�.
create or replace procedure procTeselCurriCulumTerm  
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type; 
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    open presult for
select 
oc.openclass_seq as "openclass_seq",
substr(c.curriculum,1,10)||'...' as "curriculum",
to_char(oc.curriculum_start,'yyyy-mm-dd')||'~'||to_char(oc.curriculum_end,'yyyy-mm-dd') as "curriculum_term",
cr.classroom as "classroom",
s.subject as "subject",
to_char(os.subject_start,'yyyy-mm-dd')||'~'||to_char(os.subject_end,'yyyy-mm-dd') as "subject_term",
    case 
        when os.subject_start > sysdate and os.subject_end > sysdate then '���ǿ���'
        when os.subject_start < sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end < sysdate then '��������'
    end as "subject_status",
oc.enrollment as "enrollment",
b.book as "book"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq=c.curriculum_seq
                            inner join tblsubject s 
                                on os.subject_seq=s.subject_seq
                                    inner join tblbook b
                                        on b.book_seq=os.book_seq
                                            inner join tblclassroom cr
                                                on oc.classroom_seq = cr.classroom_seq
                                                    where t.teacher_seq = vteacher_seq
                                                        order by oc.openclass_seq;

exception
    when others then
    rollback;  
end;
--ȣ��
declare
    vresult sys_refcursor;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vcurriculum tblcurriculum.curriculum%type;
    vcurriculum_term varchar2(60);
    vclassroom tblclassroom.classroom%type;
    vsubject tblsubject.subject%type;
    vsubject_term varchar2(60);
    vsubject_status varchar2(50);
    venrollment tblopencurriculum.enrollment%type;
    vbook tblbook.book%type;
begin
    procTeselCurriCulumTerm('�����',vresult);
    
    loop
        fetch vresult into vopenclass_seq,vcurriculum,vcurriculum_term,
                           vclassroom,vsubject,vsubject_term,vsubject_status,
                           venrollment,vbook;
        exit when vresult%notfound;
        dbms_output.put_line(vopenclass_seq||','||
                             vcurriculum||','||
                             vcurriculum_term||','||
                             vclassroom||','||
                             vsubject||','||
                             vsubject_term||','||
                             vsubject_status||','||
                             venrollment||','||
                             vbook
                            );   
    end loop;   
end;

-- Ư�� ���� �������� ��ȸ�Ѵ�.   --��������!!!@@@@@@@@@@@@@@@@@
create or replace procedure procTeselOsEs  
(
    pteacher in tblteacher.teacher%type,
    psubject in tblsubject.subject%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vsubject_seq tblsubject.subject_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select subject_seq into vsubject_seq from tblsubject where subject=psubject;
    open presult for
    select 
oc.curriculum_seq as "curriculum_seq",
os.subject_seq as "subject_seq",
s.student as "student",
s.tel as "tel",
es.finish_status as "finish_status",
es.p_np_date as "p_np_date"
from tblteacher t
 inner join tblopensubject os
    on t.teacher_seq=os.teacher_seq
        inner join tblopencurriculum oc
            on os.openclass_seq=oc.openclass_seq
                inner join tblenrollstudent es 
                    on oc.openclass_seq=es.openclass_seq
                        inner join tblstudent s
                            on es.student_seq=s.student_seq
                                where os.subject_seq=vsubject_seq 
                                and t.teacher_seq=vteacher_seq
                                    order by oc.curriculum_seq ;

exception
    when others then
    rollback;  
end;
--ȣ��
declare
    vresult sys_refcursor;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vsubject_seq tblsubject.subject%type;
    vstudent tblstudent.student%type;
    vtel tblstudent.tel%type;
    vfinish_status tblenrollstudent.finish_status%type;
    vp_np_date tblenrollstudent.p_np_date%type;
begin
    procTeselOsEs('�����','framework',vresult);
    
    loop
        fetch vresult into vcurriculum_seq,vsubject_seq,vstudent,
                           vtel,vfinish_status,vp_np_date;
        exit when vresult%notfound;
        
        dbms_output.put_line(vcurriculum_seq||','||
                             vsubject_seq||','||
                             vstudent||','||
                             vtel||','||
                             vfinish_status||','||
                             vp_np_date --null��ȯ�ǵ���                  
                             );
    end loop;
end;


--���� ������ ��ȸ�Ѵ�. --����+���� ����
create or replace procedure procTeselOs  
(
    pteacher in tblteacher.teacher%type,
    psubject in tblsubject.subject%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vsubject_seq tblsubject.subject_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select subject_seq into vsubject_seq from tblsubject where subject=psubject;
    open presult for
    select 
oc.openclass_seq as "openclass_seq",
c.curriculum as "curriculum",
to_char(oc.curriculum_start,'yyyy-mm-dd')||'~'||to_char(oc.curriculum_end,'yyyy-mm-dd') as "curriculum_term",
cr.classroom as "classroom",
s.subject as "subject",
to_char(os.subject_start,'yyyy-mm-dd')||'~'||to_char(os.subject_end,'yyyy-mm-dd') as "subject_term",
    case 
        when os.subject_start > sysdate and os.subject_end > sysdate then '���ǿ���'
        when os.subject_start < sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end < sysdate then '��������'
    end as "subject_status",
(select count(*) from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblenrollstudent es
                        on oc.openclass_seq=es.openclass_seq
                            where t.teacher_seq=vteacher_seq 
                            and os.subject_seq=vsubject_seq) 
                            as "enroll_stud_cnt", --���� ��ϵ� �ο���
--oc.enrollment as "enrollment", -- �ִ� ������ �ο�!  count
b.book as "book"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq=c.curriculum_seq
                            inner join tblsubject s 
                                on os.subject_seq=s.subject_seq
                                    inner join tblbook b
                                        on b.book_seq=os.book_seq
                                            inner join tblclassroom cr
                                                on oc.classroom_seq = cr.classroom_seq
                                                    where t.teacher_seq=vteacher_seq 
                                                    and os.subject_seq=vsubject_seq
                                                            order by oc.openclass_seq
                                                            ;
exception
    when others then
    rollback;  
end;
--ȣ��
declare
    vresult sys_refcursor;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vcurriculum tblcurriculum.curriculum%type;
    vcurriculum_term varchar2(60);
    vclassroom tblclassroom.classroom%type;
    vsubject tblsubject.subject%type;
    vsubject_term varchar2(60);
    vsubject_status varchar2(50);
    venrollment number;
    vbook tblbook.book%type;
begin
    procTeselOs('�����','IOT�� ����',vresult);
    
    loop
        fetch vresult into vopenclass_seq,vcurriculum,vcurriculum_term,
                           vclassroom,vsubject,vsubject_term,vsubject_status,
                           venrollment,vbook;
        exit when vresult%notfound;
        dbms_output.put_line(vopenclass_seq||','||
                             vcurriculum||','||
                             vcurriculum_term||','||
                             vclassroom||','||
                             vsubject||','||
                             vsubject_term||','||
                             vsubject_status||','||
                             venrollment||','||
                             vbook
                            );   
    end loop;   
end;

--- �ش���� ���� ���蹮���� ��ȸ�Ѵ�.
create or replace procedure procTeselOsTq  
(
    pteacher in tblteacher.teacher%type,
    psubject in tblsubject.subject%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vsubject_seq tblsubject.subject_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select subject_seq into vsubject_seq from tblsubject where subject=psubject;
    open presult for
select 
oc.openclass_seq as "openclass_seq",
os.subject_seq as "subject_seq",
s.subject as "subject",
t.teacher as "teacher",
--p.attendance as "������",
--p.written_exam as "�ʱ�",
--p.skill_test as "�Ǳ�",
td.testdate as "testdate",
tq.question as "question"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq=c.curriculum_seq
                            inner join tblsubject s 
                                on os.subject_seq=s.subject_seq
                                    inner join tblbook b
                                        on b.book_seq=os.book_seq
                                            inner join tblclassroom cr
                                                on oc.classroom_seq = cr.classroom_seq
                                                    inner join tbltest te
                                                        on os.openclass_seq=te.openclass_seq
                                                            inner join tblpoint p
                                                                on te.test_seq=p.test_seq
                                                                    inner join tbltestquestion tq
                                                                        on te.test_seq=tq.test_seq
                                                                            inner join tbltestdate td
                                                                                on te.test_seq=td.test_seq
                                                        where t.teacher_seq=vteacher_seq 
                                                        and os.subject_seq=vsubject_seq
                                                            order by oc.openclass_seq
                                                            ;
exception
    when others then
    rollback;  
end;
--ȣ��
declare
    vresult sys_refcursor;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vsubject_seq tblsubject.subject_seq%type;
    vsubject tblsubject.subject%type;
    vteacher tblteacher.teacher%type;
    vtestdate tbltestdate.testdate%type;
    vquestion tblTestQuestion.question%type;
begin
    procTeselOsTq('ȫȣ��','IOT�� ����',vresult);
    loop
        fetch vresult into vopenclass_seq,vsubject_seq,vsubject,
                           vteacher,vtestdate,vquestion;
        exit when vresult%notfound;
        dbms_output.put_line(vopenclass_seq||','||
                            vsubject_seq||','|| 
                            vsubject||','||
                            vteacher||','||
                            vtestdate||','||
                            vquestion
                            );
    end loop;
end;

--���簡 ���Ǹ� ��ģ ���� ���� ������ �Է��Ѵ�.
--@@@@@@ �� : �����Է����� ����seq�� ��������seq�� ������ �������̺��� ���� ����seq�� �����ؾ��� 
create or replace procedure procTeInsPoint
(
    pteacher in tblteacher.teacher%type,
    
    ptest_seq in tblpoint.test_seq%type,
    pattendance in tblpoint.attendance%type,
    pwritten_exam in tblpoint.written_exam%type,
    pskill_test in tblpoint.skill_test%type,
   
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    --?
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    insert into tblpoint(test_seq,attendance,written_exam,skill_test) 
        values(ptest_seq,pattendance,pwritten_exam,pskill_test); --test_seq����:�����ǰ���/�������/tbltest�� ����/��������������
        presult:=1;
exception
    when others then
        presult:=0;
        rollback;
end;

--ȣ��
declare
    vresult number;
begin
    procTeInsPoint('�ջ��',5,30,35,35,vresult);--5?
    if vresult = 1 then
        dbms_output.put_line('�Է¼���');
    elsif vresult = 0 then
        dbms_output.put_line('�Է½���');
    else
        dbms_output.put_line('�˼�����');
    end if;
end;
commit;
rollback;
    
    
--���簡 ���Ǹ� ��ģ ���� ���� ������ ��ȸ�Ѵ�.
create or replace procedure procTeselPoint
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
    select  
p.test_seq as "test_seq",
p.attendance as "attendance",
p.written_exam as "written_exam",
p.skill_test as "skill_test",
    case 
        when os.subject_start > sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end < sysdate then '��������'
    end as "subjectStatus"
from tblpoint p
    inner join tblTest t
        on p.test_seq = t.test_seq
            inner join tblopensubject os
                on t.openclass_seq=os.openclass_seq
                    inner join tblteacher tc
                        on os.teacher_seq=tc.teacher_seq
                            where tc.teacher_seq=vteacher_seq and os.subject_start < sysdate and os.subject_end < sysdate ;
exception 
    when others then
    rollback;
end;
--ȣ��
set serveroutput on;
declare
    vresult sys_refcursor;
    vtest_seq tblpoint.test_seq%type;
    vattendance tblpoint.attendance%type;
    vwritten_exam tblpoint.written_exam%type;
    vskill_test tblpoint.skill_test%type;
    vsubjectStatus varchar2(50);
begin
    procTeselPoint('�ջ��',vresult);
    loop
        fetch vresult into vtest_seq,vattendance,
                           vwritten_exam,vskill_test,vsubjectStatus;
        exit when vresult%notfound;
        
        dbms_output.put_line(vtest_seq||','||
                             vattendance||','||
                             vwritten_exam||','||
                             vskill_test||','||
                             vsubjectStatus
                             );
    end loop;
end;

--���簡 ���Ǹ� ��ģ ���� ���� ������ �Է��Ѵ�.
create or replace procedure procTeInsGrade
(
    pteacher in tblteacher.teacher%type,
    
    ptest_seq in tblpoint.test_seq%type,
    pstudent_seq in tblstudent.student%type,

    pattendance in tblpoint.attendance%type,
    pwritten_exam in tblpoint.written_exam%type,
    pskill_test in tblpoint.skill_test%type,
    
    presult out number
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    --?
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    insert into tblgrade(test_seq,student_seq,attendance,written_exam,skill_test) 
        values(ptest_seq,pstudent_seq,pattendance,pwritten_exam,pskill_test); 

exception
    when others then
        rollback;
end;

--ȣ��
declare
    vresult number;
begin
    procTeInsGrade(1,5,30,35,35,vresult);--?
    if vresult = 1 then
        dbms_output.put_line('�Է¼���');
    elsif vresult = 0 then
        dbms_output.put_line('�Է½���');
    else
        dbms_output.put_line('�˼�����');
    end if;
end;
commit;
rollback;

--���簡 ���Ǹ� ��ģ ���� ���� ������ ��ȸ�Ѵ�.
create or replace procedure procTeSelGrade
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select  
g.test_seq as "test_seq",
s.student as "student",
g.attendance as "attendance",
g.written_exam as "written_exam",
g.skill_test as "skill_test",
    case 
        when os.subject_start > sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end < sysdate then '��������'
    end as "subjectStatus"
from tblpoint p
    inner join tblTest t
        on p.test_seq = t.test_seq
            inner join tblopensubject os
                on t.openclass_seq=os.openclass_seq
                    inner join tblteacher tc
                        on os.teacher_seq=tc.teacher_seq
                            inner join tblGrade g
                                on t.test_seq=g.test_seq
                                    inner join tblstudent s
                                        on g.student_seq=s.student_seq
                            where tc.teacher_seq=vteacher_seq and os.subject_start < sysdate and os.subject_end < sysdate --���簡 �����̰� --�ױ����� �������
                                --and os.subject_seq 
                                order by g.test_seq
                            ; 
exception 
    when others then
    rollback;
end;
--ȣ��
set serveroutput on;
declare
    vresult sys_refcursor;
    vtest_seq tblgrade.test_seq%type;
    vstudent tblstudent.student%type;
    vattendance tblgrade.attendance%type;
    vwritten_exam tblgrade.written_exam%type;
    vskill_test tblgrade.skill_test%type;
    vsubjectstatus varchar2(50);
begin
    procTeSelGrade('�ջ��',vresult);
    loop
        fetch vresult into vtest_seq,vstudent,vattendance,
                           vwritten_exam,vskill_test,vsubjectstatus;
        exit when vresult%notfound;
        dbms_output.put_line(vtest_seq||','||
                             vstudent||','||
                             vattendance||','||
                             vwritten_exam||','||
                             vskill_test||','||
                             vsubjectstatus);
    end loop;
end;

-- ���簡 �ߵ� Ż�� ���θ� ��ȸ�Ѵ�.
create or replace procedure procTeselstudentStatus
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
distinct
oc.curriculum_seq as "curriculum_seq",
t.teacher as "teacher",
s.student as "student",
es.finish_status as "finish_status",
es.p_np_date as "p_np_date"

from tblteacher t 
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblenrollstudent es
                        on oc.openclass_seq=es.openclass_seq
                            inner join tblstudent s
                                on es.student_seq=s.student_seq
                                    where t.teacher_seq = vteacher_seq;
exception 
    when others then
        rollback;
end;

declare
    vresult sys_refcursor;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vteacher tblteacher.teacher%type;
    vstudent tblstudent.student%type;
    vfinish_status tblenrollstudent.finish_status%type;
    vp_np_date tblenrollstudent.p_np_date%type;
begin
    procTeselstudentStatus('�����',vresult);
    loop
        fetch vresult into vcurriculum_seq,vteacher,vstudent,
                           vfinish_status,vp_np_date;
        exit when vresult%notfound;
        dbms_output.put_line(vcurriculum_seq||','||
                             vteacher||','||
                             vstudent||','||
                             vfinish_status||','||
                             vp_np_date);
    
    end loop;
end;


--�ߵ� Ż���� �������� ������ �ߵ� Ż�� ���� �Է����� �ʴ´�.??
insert into tblgrade (student_seq,written_exam,attendance,skill_test,test_seq) 
    values (7,30,35,35)
    where <> '�ߵ�Ż��';--???????

--������ ���� �������� ��� �������� ����� ��ȸ �� �� �ִ�.
create or replace procedure procTeselAttendanceCurriculum
(
    pteacher in tblteacher.teacher%type,
    psubject in tblsubject.subject%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vopenclass_seq tblopensubject.openclass_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select os.openclass_seq into vopenclass_seq
        from tblsubject s 
            inner join tblopensubject os
                on s.subject_seq=os.subject_seq
                    where s.subject=psubject;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                            where t.teacher_seq=vteacher_seq 
                                            and oc.openclass_seq=3
                                            ;
exception 
    when others then
        rollback;
end;
--ȣ��
declare
    vresult sys_refcursor;
    vstudent tblstudent.student%type;
    vteacher tblteacher.teacher%type;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vattdate tblattendance.attdate%type;
    vattendance_status tblattendance.attendance_status%type;
    vworkin tblattendance.workin%type;
    vworkout tblattendance.workout%type;
begin
    procTeselstudentStatus('�ջ��','applet',vresult); --?
    loop
        fetch vresult into vstudent,vteacher,vcurriculum_seq,
                           vattdate,vattendance_status,vworkin,vworkout;
        exit when vresult%notfound;
        dbms_output.put_line(vstudent||','||
                             vteacher||','||
                             vcurriculum_seq||','||
                             vattdate||','||
                             vattendance_status||','||
                             vworkin||','||
                             vworkout
                             );
    end loop;
end;

-- ���簡 �Ⱓ��(��)��  �������� ����� ��ȸ �� �� �ִ�. ---�ɺ�����
create or replace procedure procTeselAttendanceMonth
(
    pteacher in tblteacher.teacher%type,
    pyearmonth in varchar2,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and substr(ad.attdate,1,7)=pyearmonth --(��,�� �Է� -> yyyy-mm-dd���·� )���ν���
                                                ;                                               
exception 
    when others then
        rollback;
end;
--ȣ��
declare
    vresult sys_refcursor;
    vstudent tblstudent.student%type;
    vteacher tblteacher.teacher%type;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vattdate tblattendance.attdate%type;
    vattendance_status tblattendance.attendance_status%type;
    vworkin tblattendance.workin%type;
    vworkout tblattendance.workout%type;
begin
    procTeselAttendanceMonth('�ջ��','2018-08',vresult); --?
    loop
        fetch vresult into vstudent,vteacher,vcurriculum_seq,
                           vattdate,vattendance_status,vworkin,vworkout;
        exit when vresult%notfound;
        dbms_output.put_line(vstudent||','||
                             vteacher||','||
                             vcurriculum_seq||','||
                             vattdate||','||
                             vattendance_status||','||
                             vworkin||','||
                             vworkout
                             );
    end loop;
end;



--���簡 �Ⱓ��(��)��  �������� ����� ��ȸ �� �� �ִ�..
--���ڴ� () �ȵ�!!!***
create or replace procedure procTeselAttendanceDay
(
    pteacher in tblteacher.teacher%type,
    pyearmonthday in varchar2,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and substr(ad.attdate,1,10)=pyearmonthday --(��,�� �Է� -> yyyy-mm-dd���·� )���ν���
                                                ;                                               
exception 
    when others then
        rollback;
end;
--ȣ��
declare
    vresult sys_refcursor;
    vstudent tblstudent.student%type;
    vteacher tblteacher.teacher%type;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vattdate tblattendance.attdate%type;
    vattendance_status tblattendance.attendance_status%type;
    vworkin tblattendance.workin%type;
    vworkout tblattendance.workout%type;
begin
    procTeselAttendanceday('�ջ��','2018-08-01',vresult); --?
    loop
        fetch vresult into vstudent,vteacher,vcurriculum_seq,
                           vattdate,vattendance_status,vworkin,vworkout;
        exit when vresult%notfound;
        dbms_output.put_line(vstudent||','||
                             vteacher||','||
                             vcurriculum_seq||','||
                             vattdate||','||
                             vattendance_status||','||
                             vworkin||','||
                             vworkout
                             );
    end loop;
end;


--���簡 Ư���ο����� �������� ����� ��ȸ �� �� �ִ�.
create or replace procedure procTeselAttenranceStudent
(
    pteacher in tblteacher.teacher%type,
    pstudent in tblstudent.student%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vstudent_seq tblstudent.student_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select student_seq into vstudent_seq from tblstudent where student=pstudent;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
    
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and s.student_seq =vstudent_seq                 
                                                ;                                            
exception 
    when others then
        rollback;
end;
--ȣ��
declare
    vresult sys_refcursor;
    vstudent tblstudent.student%type;
    vteacher tblteacher.teacher%type;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vattdate tblattendance.attdate%type;
    vattendance_status tblattendance.attendance_status%type;
    vworkin tblattendance.workin%type;
    vworkout tblattendance.workout%type;
begin
    procTeselAttenranceStudent('�����','������',vresult); --?
    loop
        fetch vresult into vstudent,vteacher,vcurriculum_seq,
                           vattdate,vattendance_status,vworkin,vworkout;
        exit when vresult%notfound;
        dbms_output.put_line(vstudent||','||
                             vteacher||','||
                             vcurriculum_seq||','||
                             vattdate||','||
                             vattendance_status||','||
                             vworkin||','||
                             vworkout
                             );
    end loop;
end;

-------------------------------------------------------------------------------------------------------------------------???????
-- ���簡 �����ȣ�� �߰��Ҽ� �־�� �Ѵ�. >>���� : �ش� ���簡 ���Ǹ� ��ģ ���� �̾�� �Ѵ�. �ش� ������ �����̾�� �Ѵ�.
create or replace procedure procTeInsTest
(
    pteacher in tblteacher.teacher%type,
    psubject in tblopensubject.subject%type,
    popenclass_seq in tblopencurriculum.openclass_seq%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vsubject_seq tblopensubject.subject_seq%type;
begin

    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    select subject_seq into vsubject_seq from tblopensubject where subject=psubject;
    
    if 
        create view vwTeInsTest
(select * from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    where os.subject_start < sysdate and os.subject_end < sysdate
                    and t.teacher_seq = );
    ;
    then
    insert into tbltest(test_seq,openclass_seq,subject_seq) values (testSeq.nextval,popenclass_seq,vsubject_seq);   
    end if;
    
exception
    when others then
        rollback;
end;

select * from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    where os.subject_start < sysdate and os.subject_end < sysdate
                    and t.teacher_seq = 9; --ȫȣ��
select * from tbltest;
select * from tbltestdate;
select * from tbltestquestion;

-- ���簡 ���賯¥�� �߰��Ҽ� �־�� �Ѵ�. >>jdbc?????????????????????
create or replace procedure procTeInsTd
(
    pteacher in tblteacher.teacher%type,
    ptest_seq in tbltestdate.test_seq%type,
    ptestdate in tbltestdate.testdate%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    
    insert into tbltestdate (test_seq,testdate) values (ptest_seq,ptestdate);
exception
    when others then
        rollback;
end;

-- ���簡 ���蹮���� �߰��Ҽ� �־�� �Ѵ�. >>jdbc?????????????????????
create or replace procedure procTeInsTq
(
    pteacher in tblteacher.teacher%type,
    ptest_seq in tbltestquestion.test_seq%type,
    pquestion in tbltestquestion.question%type,
    presult out sys_refcursor
)
is    
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    insert into tbltestquestion (test_seq,question) values (ptest_seq,pquestion);
exception
    when others then
        rollback;
end;


-- ���簡 �����ȣ�� �����Ҽ� �־�� �Ѵ�. --�����ȣ�� ������ ������ȣ�� �����ȣ ����
create or replace procedure procTeUpdTest
(
    pteacher in tblteacher.teacher%type, --�α����� ����
    ptest_seq in tbltest.test_seq%type, --������ ���� ��ȣ
    psubject_seq in tblopensubject.subject_seq%type, --������ ���� ��ȣ
    popenclass_seq in tblopencurriculum.openclass_seq%type, --������ ���� ��ȣ
    presult out sys_refcursor 
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vsubject_seq tblopensubject.subject_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    
    update tbltest set openclass_seq = popenclass_seq,
                       subject_seq = vsubject_seq 
                            where test_seq = ptest_seq
                            ;   --���翬��??????????????????

exception
    when others then
        rollback;
end;

-- ���簡 ���賯¥�� �����Ҽ� �־�� �Ѵ�. --�����ȣ�� �����Ͽ� ���� ��¥ ����
create or replace procedure procTeUpdTd
(
    pteacher in tblteacher.teacher%type,
    ptest_seq in tbltestdate.test_seq%type,
    ptestdate in tbltestdate.testdate%type,
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    
   update tbltestdate set testdate =ptestdate
                            where test_seq=ptest_seq;
exception
    when others then
        rollback;
end;

�߰��� @@@@@@@@@@@@@@@@@@@@
-- ���簡 ���蹮���� �߰��Ҽ� �־�� �Ѵ�. --�����ȣ�� �����Ͽ� ���� ��¥ ����
create or replace procedure procTeUpdTq
(
    pteacher in tblteacher.teacher%type,
    ptest_seq in tbltestquestion.test_seq%type,
    pquestion in tbltestquestion.question%type,
    presult out sys_refcursor
)
is    
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    
    update tbltestquestion set question=pquestion where test_seq=ptest_seq;

exception
    when others then
        rollback;
end;

---------------------------------------------------------------------------------------------------------------------------------

--����/������ �� ��ȸ/Ư���ο�
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher='�����'
                                                and s.student = '������' ;     --after �л��̸� �޾� seq�� ��ȯ ���ν���..?                                            
                                                  


drop procedure procTeselAttenranceStudent;

create or replace procedure procTeselAttenranceStudent
(
    pstudent varchar2,
    pteacher varchar2,
    presult out sys_refcursor
    
)
    
is  
begin


    open presult for
    select 
        s.student as "student",
        t.teacher as "teacher",
        oc.curriculum_seq as "curriculum_seq",
        ad.attdate as "attdate",
        ad.attendance_status as "attendance_status",
        ad.workin as "workin",
        ad.workout as "workout"
        
        
    from 
    tblteacher t
        inner join tblopensubject os
            on t.teacher_seq = os.teacher_seq
                inner join tblopencurriculum oc
                    on os.openclass_seq = oc.openclass_seq
                        inner join tblenrollStudent es
                           on oc.openclass_seq =es.openclass_seq
                                inner join tblattendance ad
                                    on es.student_seq=ad.student_seq
                                        inner join tblstudent s
                                            on es.student_seq=s.student_seq
                                                 where t.teacher = pteacher
                                                    and s.student = pstudent;      --after �л��̸� �޾� seq�� ��ȯ ���ν���..?                                            
                                                      

exception
    when others then
    rollback;




end;







-- ����/���� �� �� �μ�Ƽ�� ��ȸ

-- ���ݰ��� ������ �μ�Ƽ���� �Ѿ��� ��ȸ�� �� �־�� �Ѵ�.

select * from tblopensubject;

select * from tblbasicoption;
select * from tblteacherbonus;
select * from tblteacher;





select * from tblOpenSubject;


select * from tblteacher;

desc tblteacher;

procTeSelTb('ȫȣ��',vresult);

create or replace procedure procTeSelTb
(

     pteacher varchar2,
     presult out sys_refcursor 
   
)

is
begin

    
    open presult for
    select sum(bo.incentive) as incentive 
        from tblteacherbonus tb
            inner join tblopensubject os
                on tb.openclass_seq = os.openclass_seq
                and tb.subject_seq = os.subject_seq
                    inner join tblbasicoption bo
                        on tb.incentive_seq = bo.incentive_seq
                            inner join tblTeacher t
                                on t.teacher_seq = os.teacher_seq                    
                                    where t.teacher = pteacher
                                        group by os.teacher_seq;
    
exception
    when others then
    rollback;
    
    
end;

drop procedure proceTeSelTb;

declare
    vresult sys_refcursor;
    vincenSun number;

begin
    procTeSelTb('ȫȣ��',vresult);

    loop
        fetch vresult into vincenSun;
        exit when vresult%notfound;
        
        dbms_output.put_line(vincenSun ||'��');

    end loop;
end;


+++
===================================================================


       
--Ư�� ������ ���� ���������� ��ȸ�Ѵ�. 
create or replace procedure procTeselTestSeq 
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type; 
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    open presult for
select 
    tt.test_seq as test_seq,
    oc.openclass_seq as openclass_seq,
    substr(c.curriculum,1,13)||'...' as curriculum,
    s.subject as subject,
    to_char(os.subject_start,'yyyy-mm/dd')||'~'||to_char(os.subject_end,'mm/dd') as "subject_term",
    oc.classroom_seq as classroom_seq,
    to_char(td.testdate,'yyyy-mm-dd') as testdate
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq = c.curriculum_seq
                            inner join tblsubject s
                                on os.subject_seq = s.subject_seq
                                    inner join tblTest tt 
                                         on os.subject_seq = tt.subject_seq
                                            inner join tbltestdate td
                                                on tt.test_seq=td.test_seq
                                                    where t.teacher_seq = vteacher_seq
                                                        order by c.curriculum;
exception
    when others then
    rollback;  
end;


set serveroutput on;
--ȣ��
declare
    vresult sys_refcursor;
    vtest_seq tbltest.test_seq%type;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vcurriculum tblcurriculum.curriculum%type;
    vsubject tblsubject.subject%type;
    vsubject_term varchar2(60);
    vclassroom_seq tblclassroom.classroom_seq%type;
    vtestdate varchar2(30); 
begin
    procTeselTestSeq('�����',vresult);
    
    loop
        fetch vresult into vtest_seq,vopenclass_seq,vcurriculum,vsubject,
                           vsubject_term,vclassroom_seq,vtestdate;
        exit when vresult%notfound;
        dbms_output.put_line(vopenclass_seq||','||
                             vcurriculum||','||
                             vsubject||','||
                             vsubject_term||','||
                             vclassroom_seq||','||
                             vtestdate
                             );   
    end loop;   
end;

===============================================================================
===============================================================================
select * from tblteacher;
select * from tblcategory;
create or replace procedure procTeselTe
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    
begin
    open presult for 
    select * from tblteacher where teacher=pteacher;

exception
    when others then
    rollback;  
end;

--ȣ��
set serveroutput on;
declare
    vresult sys_refcursor;
    vteacher_seq tblteacher.teacher_seq%type;
    vteacher tblteacher.teacher%type;
    vssn tblteacher.ssn%type;
    vtel tblteacher.tel%type;
begin
    procTeselTe('�ջ��',vresult);
    
    loop
        fetch vresult into vteacher_seq,vteacher,vssn,vtel;
        exit when vresult%notfound;
        dbms_output.put_line(vteacher_seq||','||
                             vteacher ||','||
                             vssn||','||
                             vtel);
    end loop;
end;

commit;




create or replace procedure procTeselCurriCulumTerm  
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)

is
    vteacher_seq tblteacher.teacher_seq%type; 
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    open presult for
select 
oc.openclass_seq as "openclass_seq",
substr(c.curriculum,1,10)||'...' as "curriculum",
to_char(oc.curriculum_start,'yyyy-mm-dd')||'~'||to_char(oc.curriculum_end,'yyyy-mm-dd') as "curriculum_term",
cr.classroom as "classroom",
s.subject as "subject",
to_char(os.subject_start,'yyyy-mm-dd')||'~'||to_char(os.subject_end,'yyyy-mm-dd') as "subject_term",
    case 
        when os.subject_start > sysdate and os.subject_end > sysdate then '���ǿ���'
        when os.subject_start < sysdate and os.subject_end > sysdate then '������'
        when os.subject_start < sysdate and os.subject_end < sysdate then '��������'
    end as "subject_status",
oc.enrollment as "enrollment",
b.book as "book"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq=c.curriculum_seq
                            inner join tblsubject s 
                                on os.subject_seq=s.subject_seq
                                    inner join tblbook b
                                        on b.book_seq=os.book_seq
                                            inner join tblclassroom cr
                                                on oc.classroom_seq = cr.classroom_seq
                                                    where t.teacher_seq = vteacher_seq
                                                        order by oc.openclass_seq;

exception
    when others then
    rollback;  
end;

--ȣ��
declare
    vresult sys_refcursor;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vcurriculum tblcurriculum.curriculum%type;
    vcurriculum_term varchar2(60);
    vclassroom tblclassroom.classroom%type;
    vsubject tblsubject.subject%type;
    vsubject_term varchar2(60);
    vsubject_status varchar2(50);
    venrollment tblopencurriculum.enrollment%type;
    vbook tblbook.book%type;
begin
    procTeselCurriCulumTerm('�����',vresult);
    
    loop
        fetch vresult into vopenclass_seq,vcurriculum,vcurriculum_term,
                           vclassroom,vsubject,vsubject_term,vsubject_status,
                           venrollment,vbook;
        exit when vresult%notfound;
        dbms_output.put_line(vopenclass_seq||','||
                             vcurriculum||','||
                             vcurriculum_term||','||
                             vclassroom||','||
                             vsubject||','||
                             vsubject_term||','||
                             vsubject_status||','||
                             venrollment||','||
                             vbook
                            );   
    end loop;   
end;

commit;


create or replace procedure procTeUpdTd
(
    pteacher in tblteacher.teacher%type,
    ptest_seq in tbltestdate.test_seq%type,
    ptestdate in tbltestdate.testdate%type
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    
   update tbltestdate set testdate =ptestdate
                            where test_seq=ptest_seq;
exception
    when others then
        rollback;
end;

select * from tbltestDate;
-- -7- 2018/10/26

declare
begin
    procTeUpdTd('�����',7,'2018-10-26');
end;

select * from tblteacher;


create or replace procedure procTeUpdTq
(
    pteacher in tblteacher.teacher%type,
    ptest_seq in tbltestquestion.test_seq%type,
    pquestion in tbltestquestion.question%type
)
is    
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher; 
    
    insert into tbltestquestion values(ptest_seq,pquestion);

exception
    when others then
        rollback;
end;


declare
begin
    procTeUpdTq
end;

insert into tbltestquestion values(2,'�����ٶ󸶹ٻ����');

select * from tbltestquestion;



create or replace procedure procTeUpdPoint
(
    pteacher in tblteacher.teacher%type,
    
    ptest_seq in tblpoint.test_seq%type,
    pattendance in tblpoint.attendance%type,
    pwritten_exam in tblpoint.written_exam%type,
    pskill_test in tblpoint.skill_test%type
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    --?
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    update tblpoint set attendance=pattendance
                        ,written_exam=pwritten_exam
                        ,skill_test=skill_test
                    where test_seq = ptest_seq;
exception
    when others then
    
        rollback;
end;



--7 30 30 40
select * from tblpoint;
select * from tblTestQuestion;
delete from tbltestQuestion where question = 'framework�� �����ΰ�';











--�ش� �����ȣ�� ������ ��ȸ�Ѵ�.
select * from tbltestquestion where test_seq = 2;





--- �ش���� ���� ���蹮���� ��ȸ�Ѵ�.
create or replace procedure procTeselOsTq  
(
    pteacher in tblteacher.teacher%type,
    psubject in tblsubject.subject%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vsubject_seq tblsubject.subject_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select subject_seq into vsubject_seq from tblsubject where subject=psubject;
    open presult for
select 
oc.openclass_seq as "openclass_seq",
os.subject_seq as "subject_seq",
s.subject as "subject",
t.teacher as "teacher",
--p.attendance as "������",
--p.written_exam as "�ʱ�",
--p.skill_test as "�Ǳ�",
td.testdate as "testdate",
tq.question as "question"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq=os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq=oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq=c.curriculum_seq
                            inner join tblsubject s 
                                on os.subject_seq=s.subject_seq
                                    inner join tblbook b
                                        on b.book_seq=os.book_seq
                                            inner join tblclassroom cr
                                                on oc.classroom_seq = cr.classroom_seq
                                                    inner join tbltest te
                                                        on os.openclass_seq=te.openclass_seq
                                                            inner join tblpoint p
                                                                on te.test_seq=p.test_seq
                                                                    inner join tbltestquestion tq
                                                                        on te.test_seq=tq.test_seq
                                                                            inner join tbltestdate td
                                                                                on te.test_seq=td.test_seq
                                                        where t.teacher_seq=vteacher_seq 
                                                        and os.subject_seq=vsubject_seq
                                                            order by oc.openclass_seq
                                                            ;
exception
    when others then
    rollback;  
end;
--ȣ��
declare
    vresult sys_refcursor;
    vopenclass_seq tblopencurriculum.openclass_seq%type;
    vsubject_seq tblsubject.subject_seq%type;
    vsubject tblsubject.subject%type;
    vteacher tblteacher.teacher%type;
    vtestdate tbltestdate.testdate%type;
    vquestion tblTestQuestion.question%type;
begin
    procTeselOsTq('ȫȣ��','IOT�� ����',vresult);
    loop
        fetch vresult into vopenclass_seq,vsubject_seq,vsubject,
                           vteacher,vtestdate,vquestion;
        exit when vresult%notfound;
        dbms_output.put_line(vopenclass_seq||','||
                            vsubject_seq||','|| 
                            vsubject||','||
                            vteacher||','||
                            vtestdate||','||
                            vquestion
                            );
    end loop;
end;


select * from tblpoint where test_seq = 7;


select 
    distinct c.curriculum
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq =c.curriculum_seq
                            where t.teacher_seq = 2;


--�ش� ������ ������ ��ȸ�Ѵ�.
create or replace procedure procTeselCurriculum  
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    open presult for
    
select 
    distinct
    c.curriculum_seq as curriculum_seq,
    c.curriculum as curriculum
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq =c.curriculum_seq
                            where t.teacher_seq = vteacher_seq;
exception
    when others then
    rollback;  
end;

select * from tblcurriculum












create or replace procedure procAdmselAttendanceDay
(
    pteacher in tblteacher.teacher%type,
    pcurriculum_seq in tblopencurriculum.curriculum_seq%type,
    pyearmonthday in varchar2,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and oc.curriculum_seq = pcurriculum_seq
                                                and substr(ad.attdate,1,10)=pyearmonthday --(��,�� �Է� -> yyyy-mm-dd���·� )���ν���
                                                ;                                               
exception 
    when others then
        rollback;
end;


select * from tblgrade;
delete tblgrade where student_seq = 18 and test_seq = 12;

set serveroutput on;
--ȣ��
declare
    vresult sys_refcursor;
    vstudent tblstudent.student%type;
    vteacher tblteacher.teacher%type;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vattdate tblattendance.attdate%type;
    vattendance_status tblattendance.attendance_status%type;
    vworkin tblattendance.workin%type;
    vworkout tblattendance.workout%type;
begin
    procTeselAttendanceday('�����','5','2018-08-01',vresult); --?
    loop
        fetch vresult into vstudent,vteacher,vcurriculum_seq,
                           vattdate,vattendance_status,vworkin,vworkout;
        exit when vresult%notfound;
        dbms_output.put_line(vstudent||','||
                             vteacher||','||
                             vcurriculum_seq||','||
                             vattdate||','||
                             vattendance_status||','||
                             vworkin||','||
                             vworkout
                             );
    end loop;
end;












create or replace procedure procTeselAttendanceMonth
(
    pteacher in tblteacher.teacher%type,
    pcurriculum_seq in tblopencurriculum.curriculum_seq%type,
    pyearmonth in varchar2,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and oc.curriculum_seq = pcurriculum_seq
                                                and to_char(ad.attdate,'yyyy')||'-'||to_char(ad.attdate,'mm')
                                                        =pyearmonth --(��,�� �Է� -> yyyy-mm-dd���·� )���ν���
                                                ;                                               
exception 
    when others then
        rollback;
end;



declare
    vresult sys_refcursor;
    vstudent tblstudent.student%type;
    vteacher tblteacher.teacher%type;
    vcurriculum_seq tblopencurriculum.curriculum_seq%type;
    vattdate tblattendance.attdate%type;
    vattendance_status tblattendance.attendance_status%type;
    vworkin tblattendance.workin%type;
    vworkout tblattendance.workout%type;
begin
    procTeselAttendanceMonth('�����','5','2018-08',vresult); --?
    loop
        fetch vresult into vstudent,vteacher,vcurriculum_seq,
                           vattdate,vattendance_status,vworkin,vworkout;
        exit when vresult%notfound;
        dbms_output.put_line(vstudent||','||
                             vteacher||','||
                             vcurriculum_seq||','||
                             vattdate||','||
                             vattendance_status||','||
                             vworkin||','||
                             vworkout
                             );
    end loop;
end;


create or replace procedure procTeselAttendanceCurriculum
(
    pteacher in tblteacher.teacher%type,
    psubject in tblsubject.subject%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vopenclass_seq tblopensubject.openclass_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select os.openclass_seq into vopenclass_seq
        from tblsubject s 
            inner join tblopensubject os
                on s.subject_seq=os.subject_seq
                    where s.subject=psubject;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                            where t.teacher_seq=vteacher_seq 
                                            and oc.openclass_seq=3
                                            ;
exception 
    when others then
        rollback;
end;




--�� ��� ��ȸ

create or replace procedure procTeselAttendanceCurriculum
(
    pteacher in tblteacher.teacher%type,
    pcurriculum_seq in tblopencurriculum.curriculum_seq%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and oc.curriculum_seq = pcurriculum_seq
                                               ;                                               
exception 
    when others then
        rollback;
end;





--���簡 Ư���ο����� �������� ����� ��ȸ �� �� �ִ�.
create or replace procedure procTeselAttenranceStudent
(
    pteacher in tblteacher.teacher%type,
    pcurriculum_seq in tblopencurriculum.curriculum_seq%type,
    pstudent in tblstudent.student%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vstudent_seq tblstudent.student_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select student_seq into vstudent_seq from tblstudent where student=pstudent;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
    
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and oc.curriculum_seq = pcurriculum_seq
                                                and s.student_seq =vstudent_seq                 
                                                ;                                            
exception 
    when others then
        rollback;
end;

--Ư�� ���� Ư�� ������ �л���� ����ϱ�
create or replace procedure procTeselAttenranceStudent
(
    pteacher in tblteacher.teacher%type,
    pcurriculum_seq in tblopencurriculum.curriculum_seq%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    open presult for
select 
    oc.curriculum_seq as curriculum_seq,
    es.student_seq as student_seq,
    s.student as student
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollstudent es
                        on oc.openclass_seq = es.openclass_seq
                            inner join tblstudent s
                                on es.student_seq = s.student_seq
                                    where t.teacher_seq=vteacher_seq
                                        and oc.curriculum_seq = pcurriculum_seq                                        
                                        ;                                                        
exception 
    when others then
        rollback;
end;



select 
    oc.curriculum_seq as curriculum_seq,
    es.student_seq as student_seq,
    s.student as student
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollstudent es
                        on oc.openclass_seq = es.openclass_seq
                            inner join tblstudent s
                                on es.student_seq = s.student_seq
                                    where t.teacher_seq=2
                                        and oc.curriculum_seq = 5                                      
                                        ;   
                                        
                                        
                                        
                                        
-------------------------------------------------------------                                       
create or replace procedure procTeselCertainStudAttend
(
    pteacher in tblteacher.teacher%type,
    pstudent in tblstudent.student%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
    vstudent_seq tblstudent.student_seq%type;
begin
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    select student_seq into vstudent_seq from tblstudent where student=pstudent;
    
    open presult for
select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
    
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=vteacher_seq
                                                and s.student_seq =vstudent_seq                 
                                                ;                                            
exception 
    when others then
        rollback;
end;                                        
                                        
                   
                   
                   select 
    s.student as "student",
    t.teacher as "teacher",
    oc.curriculum_seq as "curriculum_seq",
    ad.attdate as "attdate",
    ad.attendance_status as "attendance_status",
    ad.workin as "workin",
    ad.workout as "workout"
    
from 
tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollStudent es
                       on oc.openclass_seq =es.openclass_seq
                            inner join tblattendance ad
                                on es.student_seq=ad.student_seq
                                    inner join tblstudent s
                                        on es.student_seq=s.student_seq
                                             where t.teacher_seq=2
                                                and s.student_seq = 37             
                                                ;       
                                          
                                                
 --���簡 ���Ǹ� ��ģ ���� ���� ������ �Է��Ѵ�.
create or replace procedure procTeInsGrade
(
    pteacher in tblteacher.teacher%type,
    
    ptest_seq in tblpoint.test_seq%type,
    
    pstudent_seq in tblstudent.student%type,
    pattendance in tblpoint.attendance%type,
    pwritten_exam in tblpoint.written_exam%type,
    pskill_test in tblpoint.skill_test%type,
    
    presult out number
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    --?
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    insert into tblgrade(test_seq,student_seq,attendance,written_exam,skill_test) 
        values(ptest_seq,pstudent_seq,pattendance,pwritten_exam,pskill_test); 
exception
    when others then
        rollback;
end;                                               
                                                

---------------------------------------------------------------------------------------------------------------

create or replace procedure procTeInsGrade
(
    pteacher in tblteacher.teacher%type,
    
    ptest_seq in tblpoint.test_seq%type,
    
    pstudent_seq in tblstudent.student%type,
    pattendance in tblpoint.attendance%type,
    pwritten_exam in tblpoint.written_exam%type,
    pskill_test in tblpoint.skill_test%type,
    
    presult out number
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    --?
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    insert into tblgrade(test_seq,student_seq,attendance,written_exam,skill_test) 
        values(ptest_seq,pstudent_seq,pattendance,pwritten_exam,pskill_test); 
        
 
    
exception
    when others then
        rollback;
end;               

select * from tblSubjectGradeStatus;
---------------------------------------------------------------------------------------------------------------




                                                
                                                
select * from tblgrade;      

--Ư�����簡 ��ģ ������� �����ȸ
select 
os.openclass_seq as openclass_seq,
sub.subject as subject,
es.student_seq as student_seq,
s.student as student,
    (select test_seq from tbltest where openclass_seq=os.openclass_seq and subject_seq = os.subject_seq ) as test_seq,
sgs.grade_status
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblsubject sub
                on os.subject_seq = sub.subject_seq
            inner join tblopencurriculum oc 
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollstudent es
                        on oc.openclass_seq = es.openclass_seq
                            inner join tblStudent s
                                on es.student_seq = s.student_seq
                                    inner join tblsubjectGradestatus sgs
                                        on os.openclass_seq = sgs.openclass_seq
                                    where t.teacher_seq = 9 and os.class_status='��������'
                                        order by os.openclass_seq;
                                        
select * from tblgrade;
select * from tbltest;

commit;
select * from tblopensubject;


create or replace procedure procTeEndList
(
    pteacher in tblteacher.teacher%type,
    presult out sys_refcursor
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin
    
    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    open presult for
select 
os.openclass_seq as openclass_seq,
sub.subject as subject,
es.student_seq as student_seq,
s.student as student,
    (select test_seq from tbltest where openclass_seq=os.openclass_seq and subject_seq = os.subject_seq ) as test_seq,
sgs.grade_status as grade_status
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblsubject sub
                on os.subject_seq = sub.subject_seq
            inner join tblopencurriculum oc 
                on os.openclass_seq = oc.openclass_seq
                    inner join tblenrollstudent es
                        on oc.openclass_seq = es.openclass_seq
                            inner join tblStudent s
                                on es.student_seq = s.student_seq
                                    inner join tblsubjectGradestatus sgs
                                        on os.openclass_seq = sgs.openclass_seq
                                    where t.teacher_seq = vteacher_seq and os.class_status='��������'
                                        order by os.openclass_seq;
exception
    when others then
        rollback;
end;                                       

select * from tblteacher;
select * from tblgrade;



--������� ������ �����ȸ (�ܽ����ȣ�� �����ϴ� ������)

--�Է� 


create or replace procedure procTeInsGrade
(
    pteacher in tblteacher.teacher%type,
    
    ptest_seq in tblpoint.test_seq%type,
    pstudent_seq in tblstudent.student%type,

    pattendance in tblpoint.attendance%type,
    pwritten_exam in tblpoint.written_exam%type,
    pskill_test in tblpoint.skill_test%type,
    
    presult out number
)
is
    vteacher_seq tblteacher.teacher_seq%type;
begin

    select teacher_seq into vteacher_seq from tblteacher where teacher=pteacher;
    
    insert into tblgrade (student_seq,attendance,written_exam,skill_test,test_seq)
        values(pstudent_seq, pattendance, pwritten_exam, pskill_test,ptest_seq);
exception
    when others then
        rollback;
end;


commit;

--ȣ��
declare
    vresult number;
begin
    procTeInsGrade('ȫȣ��',5,14,30,35,35,vresult);--?
    dbms_output.put_line(vresult);
end;



desc tblgrade;

commit;
rollback;

select * from tbltest;
select * from tblgrade;
select * from tblteacher;

--�����ȣ : 12 �л���ȣ :18
delete tblgrade where test_seq = 12 and student_seq=18;
   
insert into tblgrade values(14,30,35,35,5);

commit;
rollback;

dele
select * from tblstudent;
select * from tbltest;
select * from tblteacher;
desc tblgrade;




select * from tblteacher;


create or replace procedure procAdmselCurriculum  
(
    presult out sys_refcursor
)
is
begin
    open presult for  
select 
    distinct
    c.curriculum_seq as curriculum_seq,
    c.curriculum as curriculum
from tblteacher t
    inner join tblopensubject os
        on t.teacher_seq = os.teacher_seq
            inner join tblopencurriculum oc
                on os.openclass_seq = oc.openclass_seq
                    inner join tblcurriculum c
                        on oc.curriculum_seq =c.curriculum_seq
                          ;
exception
    when others then
    rollback;  
end;





select * from tblgrade;
delete tblgrade where student_seq = 18 and test_seq = 12;
commit;




select * from tblteacherscore;

select * from tbltestdate;
update tbltestdate set testdate = '2018-08-02' where test_seq=5; 


set SERVEROUTPUT ON;

declare
    vresult sys_refcursor;
begin
    procstupdteacherscore(1,1,10,1,2,3,4,5,vresult);
end;

select * from tblteacherscore;
select * from
update tblteacherscore set  where student_seq=10 and score_seq = 1;
select * from tblteacherscore;
select * from tblteacherscore;
procstupdteacherscore(1,1,10,2,2,2,2,2,vresult);

























