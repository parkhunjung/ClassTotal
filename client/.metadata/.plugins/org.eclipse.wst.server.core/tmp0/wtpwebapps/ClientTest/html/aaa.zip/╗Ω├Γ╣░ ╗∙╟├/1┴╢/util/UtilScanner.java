package com.test.util;

import java.util.Scanner;

public class UtilScanner {

	Scanner scan;

	public UtilScanner() {
		scan = new Scanner(System.in);
	}

	public String next(String label) {
		System.out.print(label + ":");
		return scan.nextLine();
	}

	public int nextInt(String label) {
		System.out.print(label + ":");
		return Integer.parseInt(scan.nextLine());
	}

	public String nextln(String label) {
		System.out.println(label + ":");
		return scan.nextLine();
	}

	public int nextIntln(String label) {
		System.out.println(label + ":");
		return Integer.parseInt(scan.nextLine());
	}

	public String nextLine() {
		return scan.nextLine();
	}

	public int nextInt() {
		int num = scan.nextInt();
		scan.skip("\r\n");
		return num;
	}
}
