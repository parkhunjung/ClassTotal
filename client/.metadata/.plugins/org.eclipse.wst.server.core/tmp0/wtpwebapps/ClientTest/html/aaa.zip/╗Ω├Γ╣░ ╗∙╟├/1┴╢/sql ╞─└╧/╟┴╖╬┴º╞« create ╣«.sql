-- ����
--���� ����
create table tblInstructor(

    id varchar2(10) primary key,
    name varchar2(15) not null,
    tel varchar2(15),
    constraint tblInstructor_id_fk foreign key(id) references tblLogin(id)
    );
    
--���̺���_�÷���_�����������

--������������
create table tblCourseBase(
    seq number primary key,
    courseName varchar2(30) not null,
    regitPersonnel number(3) null,
    courseNum number not null references tblCourse(courseNum),
    textBookNum number null references tblTextBook(textBookNum)
    
);


--������ ���Ῡ��
create table tblStudentComplete(
    registerNum number not null primary key,
    status number(1) null,
    compDate date null,
    omissionDate date null,
    constraint tblStudentComplete_id_fk foreign key(registerNum) references tblRegisterCourse(registerNum)
    
    );


----------------------------------------------
-- �ʸ�
Create table tblTextBook ( -- ���� ���� tbl
    textBookNum number primary key,
    textBookName varchar2(20) not null,
    author varchar2(15) not null,
    publisher varchar2(30) not null
);


Create table tblSubject ( -- ���� tbl
    sbjNum number primary key,
    sbjName varchar2(30) not null
);

create table tblMaterial ( -- ���� ��� tbl
    seq number primary key,
    material varchar2(20) not null,
    qty number(3) null,
    lectureRoomNum number(1) not null,
    
    constraint tblAMaterial_lectureRoomNum_fk 
        foreign key(lectureRoomNum) 
            references tblLectureRoom(lectureRoomNum)
    
);

create table tblexecSbject ( -- ���࿡ ���� ���� ���� tbl
    execsbjnum number primary key,
    courseNum number,
    startDate date not null,
    endDate date not null,
    examDate date,
    instruction varchar2(100),
    sbjNum number,
    
    constraint tblexecSbject_courseNum_fk
        foreign key(courseNum)
            references tblCourse(courseNum),
            
    constraint tblexecSbject_sbjNum_fk
        foreign key(sbjNum)
            references tblSubJect(sbjNum)

);

create table tblRegisterCourse ( -- ������û���� tbl
    registerNum number primary key,
    id varchar2(10) not null,
    courseNum number not null,
    
    constraint tblRegisterCourse_id_fk
        foreign key(id)
            references tblStudent(id),
            
    constraint tblRegisterCourse_courseNum_fk
        foreign key(courseNum)
            references tblCourse(courseNum)
);

create table tblStudentReview ( -- ����� �ı� tbl
    registerNum number PRIMARY key,
    review varchar2(1000) null,
    
    constraint tblStudentReview_registNum_fk
        foreign key(registerNum)
            references tblStudentComplete(registerNum)
);
--------------------------------------------
-- ����
create table tblAdmin --������ ���̺�
(
    id varchar2(10) primary key,
    name varchar2(15) null,
    dateofemp date null,
    address varchar2(100) null,
    tel varchar2(15) null,
    constraint tblAdmin_id_fk foreign key(id) references tblLogin(id)
);



create table tblInstSbj --�������ɱ��� ���̺�
(
    seq number primary key,
    sbjnum number not null references tblSubject(sbjnum), 
    id varchar2(10) not null references tblInstructor(id)  
);


create table tblCourse --���� ���� ���̺�
(
    courseNum number primary key,
    startDate DATE null,
    endDate date null,
    regitStatus varchar2(10) not null,
    id varchar2(10)  null references tblInstructor(id),
    lectureRoomNum number(1) null references tblLectureRoom(lectureRoomNum)
);



create table tblStuAttendance --������ ���� ��Ȳ ���̺�
(
    seq number primary key,
    attendenceDate date not null,
    enterTime date null,
    exitTime date null,
    note varchar2(10) null,
    registerNum number null, 
    
    constraint tblStuAttendance_seq2_fk foreign key(registerNum) references tblRegisterCourse(registerNum)
);

create table tblScore -- ���� ���� ���̺�
(
    seq number primary key,
    attendScore  number(3) not null,
    writeScore number(3) not null,
    practiceScore number(3) not null,
    registerNum number not null,
    execsbjnum number not null,
    
    constraint tblScore_registerNum_fk foreign key(registerNum) references tblRegisterCourse(registerNum),
    constraint tblScore_execsbjnum_fk foreign key(execsbjnum) references tblexecSbject(execsbjnum)
    
);
---------------------------------------------------
-- ����
create table tblStudent --����������
(
    id varchar2(10) not null primary key, --������ ��ȣ
    name varchar2(15) not null, --������ ��
    tel varchar2(15), -- ��ȭ��ȣ
    regitDate date, -- �����
    majorCheck varchar2(10) not null, --��������
    constraint tblStudent_id_fk foreign key(id) references tblLogin(id) 
);

create table tblExam --���蹮��
(
    seq number not null primary key, --�Ϸù�ȣ
    execsbjnum number not null , --��������ȣ
    examNum number, --���蹮����ȣ
    question varchar2(1000), --���蹮��
    answer number(1), --����
    score number(2), --����
    constraint tblExam_execsbjnum_fk foreign key(execsbjnum) 
    references tblexecSbject(execsbjnum)   
);

create table tblAppraisal --������
(
    courseNum number not null, --������ȣ
    apprajsal varchar2(1000), --�򰡳���
    createDate date not null, --�ۼ���¥
    registerNum number, --������û��ȣ
    constraint tblAppraisal_courseNum_fk foreign key(courseNum) 
    references tblCourse(courseNum),
    constraint tblAppraisal_registerNum_fk foreign key(registerNum)
    references tblRegisterCourse(registerNum)
);

create table tblStudentEmploymentInfo --������ ��� ����
(
    registerNum number not null primary key, --������û��ȣ
    workplace varchar2(50), --�����
    constraint tblStudentEmpInfo_registNum_fk foreign key(registerNum)
    references tblStudentComplete(registerNum)
);
------------------------------------------------------
-- ����
create table tblLogin( -- �α���
    id varchar2(10) primary key NOT NULL,
    pw varchar2(7) NOT NULL
);

create table tblLectureRoom( -- ���ǽ� ����                         
    lectureRoomNum number(1) primary key NOT NULL,
    limitNum number(2) NOT NULL
); 

create table tblPermission( -- ����
    permissionNum number primary key,
    permissionName varchar2(20)
);

create table tblLoginPermission( -- �α����� ����
    seq number primary key not null,
    id varchar2(10) not null,
    permissionNum number,
    constraint tblLoginPermission_id_fk foreign key(id) references tblLogin(id),
    constraint tblLoginPermission_permNum_fk foreign key(permissionNum) references tblPermission(permissionNum)
);

create table tblCourseSbject( -- ������ ���� ��������
    seq number primary key not null,
    coursebaseNum number not null,
    sbjNum number not null,
    constraint tblCourseSbject_coursebNum_fk foreign key(coursebaseNum) references tblCourseBase(seq),
    constraint tblCourseSbject_sbjNum_fk foreign key(sbjNum) references tblSubject(sbjNum)   
);

create table tblStudentExpense( -- ������ �Ʒú� ����
    registerNum number primary key not null,
    paymentDate date not null,
    money number(6) null,
    paymentStatus number(1) not null,
    constraint tblStudentExpense_rNum_fk foreign key(registerNum) references tblRegisterCourse(registerNum)
);




create table tblScoreInfo(
    execsbjnum number primary key,
    attendScoring number(3),
    writeScoring number(3),
    practiceScoring number(3),
    check(attendScoring + writeScoring + practiceScoring = 100)
);
