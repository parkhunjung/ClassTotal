package com.test.util;

import java.util.Iterator;
import java.util.Stack;

import com.test.notice.MainClass;

public class BreadCrumb {
	
	private Stack<String> stack;
	
	public BreadCrumb(){
		this.stack = new Stack<String>();
	}
	
	public void in(String title) {
		stack.push(title);
	}
	
	public void out() {
		stack.pop();
	}
	
	public void now() {
		// stack loop 출력
		
		Iterator<String> iter = stack.iterator();
		
		System.out.println();
		
		String temp = String.format("[%s 접속중] ",MainClass.isAuth != null ? MainClass.isAuth:"guest");
		
		while(iter.hasNext()) {
			temp += iter.next()+" ▷ ";
		}
		
		System.out.println(temp.substring(0,temp.length()-3));
		
		System.out.println();
	}
	
//	public static void main(String[] args) {
//		
//		BreadCrumb crumb = new BreadCrumb();
//		
//		crumb.in("알림장");
//		crumb.in("유저");
//		crumb.in("유저 가입");
//		
//		crumb.now();
//		
//		crumb.out();
//		
//		crumb.now();
//		
//		crumb.in("로그인");
//		
//		crumb.now();
//		
//		crumb.out();
//		crumb.out();
//		crumb.now();
//	}
	
}
