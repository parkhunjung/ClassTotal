--Project_function.sql

--���� seq�� ã�Ƴ��� �Լ�
create or replace function fnGetSubject_seq
(
    psubject varchar2
)return number
is
    vcnt number;
    vseq number;
begin
    
    vseq := 0;
    
    select count(*) into vcnt from tblSubject where subject = psubject;
    
    if vcnt = 1 then
    
        select subject_seq into vseq from tblSubject where subject = psubject;
        return vseq;
    else 
        return 0;
    end if;
    
exception
    when others then
    return 0;
end;


--���� seq�� ã�� �Լ�
create or replace function fnGetCurriculum_seq
(
    pcurriculum varchar2
)return number
is
    vcnt number;
    vseq number;
begin
    
    vseq := 0;
    
    select count(*) into vcnt from tblcurriculum where curriculum = pcurriculum;
    
    if vcnt = 1 then
    
        select curriculum_seq into vseq from tblcurriculum where curriculum = pcurriculum;
        return vseq;
    else 
        return 0;
    end if;
    
exception
    when others then
    return 0;
end;


--���ǽ� seq�� ã�� �Լ�
create or replace function fnGetclassroom_seq
(
    pclassroom varchar2
)return number
is
    vcnt number;
    vseq number;
begin
    
    vseq := 0;
    
    select count(*) into vcnt from tblclassroom where classroom = pclassroom;
    
    if vcnt = 1 then
    
        select classroom_seq into vseq from tblclassroom where classroom = pclassroom;
        return vseq;
    else 
        return 0;
    end if;
    
exception
    when others then
    return 0;
end;


--���� seq�� ã�� �Լ�
create or replace function fnGetBook_seq
(
    pbook varchar2
)return number
is
    vcnt number;
    vseq number;
begin
    
    vseq := 0;
    
    select count(*) into vcnt from tblbook where book = pbook;
    
    if vcnt = 1 then
    
        select book_seq into vseq from tblbook where book = pbook;
        return vseq;
    else 
        return 0;
    end if;
    
exception
    when others then
    return 0;
end;


--���� seq�� ã�� �Լ�
create or replace function fnGetTeacher_seq
(
    pteacher varchar2
)return number
is
    vcnt number;
    vseq number;
begin
    
    vseq := 0;
    
    select count(*) into vcnt from tblteacher where teacher = pteacher;
    
    if vcnt = 1 then
    
        select teacher_seq into vseq from tblteacher where teacher = pteacher;
        return vseq;
    else 
        return 0;
    end if;
    
exception
    when others then
    return 0;
end;

--�л� seq�� ã�� �Լ�
create or replace function fnGetStudent_seq
(
	pstudent varchar2
) return number
is
	vcnt number;
	vseq number;
begin

	vseq := 0;
	
	select count(*) into vcnt from tblstudent where student = pstudent;

	if vcnt = 1 then
		
		select student_seq into vseq from tblstudent where student = pstudent;
		return vseq;
	else
		return 0;
	end if;

exception
	when others then
	rollback;
end;

